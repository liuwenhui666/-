#include <string.h>
#include "fpr_zn632.h"
#include "delay.h"

/* ================================================================
 * ZN632 命令码定义
 * ================================================================ */
#define CMD_GetImage        0x01
#define CMD_GenChar         0x02
#define CMD_Match           0x03
#define CMD_Search          0x04
#define CMD_RegModel        0x05
#define CMD_StoreChar       0x06
#define CMD_LoadChar        0x07
#define CMD_UpChar          0x08
#define CMD_DownChar        0x09
#define CMD_UpImage         0x0A
#define CMD_DownImage       0x0B
#define CMD_DeletChar       0x0C
#define CMD_Empty           0x0D
#define CMD_WriteReg        0x0E
#define CMD_ReadSysPara     0x0F
#define CMD_VryPwd          0x13
#define CMD_GetRandomCode   0x14
#define CMD_SetChipAddr     0x15
#define CMD_ReadINFpage     0x16
#define CMD_Port_Control    0x17
#define CMD_HighSpeedSearch 0x1B
#define CMD_ReadIndexTable  0x1F

/* ================================================================
 * 宏定义
 * ================================================================ */
#define ZN632_DELAY_MS(x)  delay_ms(x)
#define ZN632_USART         USART1
#define ZN632_BUF_LEN       128
#define ZN632_INDEX_MAX     240

/* ================================================================
 * 全局变量
 * ================================================================ */
uint32_t ZN632_RxBufLen = 0;
uint8_t  ZN632_RxBuf[ZN632_BUF_LEN];
uint8_t  ZN632_ADDR[4]  = {0xFF, 0xFF, 0xFF, 0xFF};
uint8_t  ZN632_INDEX[32] = {0};           // 指纹ID索引位图
uint8_t  g_uExitToChange = 0;             // 强制退出标志

/* ================================================================
 * 函数声明
 * ================================================================ */
static void ZN632_GPIO_Init(void);
static void ZN632_UART_Init(uint32_t baud);
static void ZN632_SendData(uint8_t *data, uint8_t length);
static void ZN632_SendHead(void);
static void ZN632_ShowError(uint16_t code);
static void ZN632_ClearRxBuf(void);
static int16_t ZN632_CheckAck(void);
static int8_t  FPR_GetImage(void);

/* ================================================================
 * FPR 初始化
 * ================================================================ */

void FPR_Init(uint32_t baud)
{
    ZN632_GPIO_Init();
    ZN632_UART_Init(baud);
    ZN632_PowerOn();
}

static void ZN632_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);

    // PC9: FPR电源控制线
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    GPIO_SetBits(GPIOC, GPIO_Pin_9);  // 默认断电
}

static void ZN632_UART_Init(uint32_t baud)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    // PA9-TX, PA10-RX 复用为 USART1
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource9,  GPIO_AF_USART1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);

    USART_InitStructure.USART_BaudRate            = baud;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(ZN632_USART, &USART_InitStructure);

    USART_ITConfig(ZN632_USART, USART_IT_RXNE, ENABLE);
    USART_Cmd(ZN632_USART, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel                   = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

/**
  * @brief  FPR模块上电并等待启动完成
  * @retval  0=成功, -1=超时
  */
int16_t ZN632_PowerOn(void)
{
    uint32_t timeout = 0;

    ZN632_ClearRxBuf();
    GPIO_ResetBits(GPIOC, GPIO_Pin_9);  // 拉低PC9: 给FPR上电
    ZN632_DELAY_MS(500);                // 等待模块上电稳定

    // 等待启动包: EF 01 FF FF FF FF 07 00 03 0A 00 55...
    while (1) {
        if (ZN632_RxBufLen >= 9 &&
            ZN632_RxBuf[0] == 0xEF &&
            ZN632_RxBuf[1] == 0x01 &&
            ZN632_RxBuf[6] == 0x07 &&
            ZN632_RxBuf[8] == 0x03) {
            ZN632_ClearRxBuf();
            return 0;
        }

        timeout++;
        if (timeout > 3000) {           // 约3秒超时
            ZN632_ClearRxBuf();
            return -1;
        }
        ZN632_DELAY_MS(1);
    }
}

/* ================================================================
 * USART1 中断服务
 * ================================================================ */

void USART1_IRQHandler(void)
{
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        if (ZN632_RxBufLen < ZN632_BUF_LEN) {
            ZN632_RxBuf[ZN632_RxBufLen++] = USART_ReceiveData(USART1);
        } else {
            USART_ReceiveData(USART1);   // 丢弃溢出数据
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}

/* ================================================================
 * 串口收发 & 缓冲区管理
 * ================================================================ */

static void ZN632_SendData(uint8_t *data, uint8_t length)
{
    uint8_t i;
    for (i = 0; i < length; i++) {
        USART_SendData(ZN632_USART, data[i]);
        while (USART_GetFlagStatus(ZN632_USART, USART_FLAG_TXE) == RESET);
    }
}

static void ZN632_SendHead(void)
{
    uint8_t head[6];
    head[0] = 0xEF;
    head[1] = 0x01;
    head[2] = ZN632_ADDR[0];
    head[3] = ZN632_ADDR[1];
    head[4] = ZN632_ADDR[2];
    head[5] = ZN632_ADDR[3];
    ZN632_SendData(head, 6);
}

static void ZN632_ClearRxBuf(void)
{
    memset(ZN632_RxBuf, 0, ZN632_RxBufLen);
    ZN632_RxBufLen = 0;
}

/* ================================================================
 * 应答包校验
 * ================================================================ */

static int16_t ZN632_CheckAck(void)
{
    uint16_t i, temp = 0, sum = 0, len = 0;

    // 包头检查
    if (ZN632_RxBufLen < 9) return -1;
    if (ZN632_RxBuf[0] != 0xEF || ZN632_RxBuf[1] != 0x01) return -1;

    // 地址码检查
    if (ZN632_RxBuf[2] != ZN632_ADDR[0] ||
        ZN632_RxBuf[3] != ZN632_ADDR[1] ||
        ZN632_RxBuf[4] != ZN632_ADDR[2] ||
        ZN632_RxBuf[5] != ZN632_ADDR[3]) {
        return -1;
    }

    len = (uint16_t)ZN632_RxBuf[7] << 8 | ZN632_RxBuf[8];
    if (ZN632_RxBufLen < (uint32_t)(9 + len)) return -1;  // 数据不足

    // 校验和
    temp = 0;
    for (i = 0; i <= len; i++) {
        temp += ZN632_RxBuf[6 + i];
    }
    sum = (uint16_t)ZN632_RxBuf[9 + len - 2] << 8 | ZN632_RxBuf[9 + len - 1];
    if (sum != temp) return -1;

    return ZN632_RxBuf[9];  // 返回确认码
}

/* ================================================================
 * 基础命令
 * ================================================================ */

/**
  * @brief  密码验证
  */
int16_t ZN632_VryPwd(void)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[10] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x07;
    cmd[3] = CMD_VryPwd;
    // cmd[4]~cmd[7] 密码 = 0x00000000 (默认)

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3] + cmd[4] + cmd[5] + cmd[6] + cmd[7];
    cmd[8] = temp >> 8;
    cmd[9] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 10);
    ZN632_DELAY_MS(300);

    ret = ZN632_CheckAck();
    if (ret != 0) ZN632_ShowError(ret);
    ZN632_ClearRxBuf();
    return ret;
}

/**
  * @brief  读取指纹索引表
  */
int16_t ZN632_ReadIndexTable(void)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[7] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x04;
    cmd[3] = CMD_ReadIndexTable;
    cmd[4] = 0;  // 页码0

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3] + cmd[4];
    cmd[5] = temp >> 8;
    cmd[6] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 7);
    ZN632_DELAY_MS(300);

    ret = ZN632_CheckAck();
    if (ret != 0) {
        ZN632_ShowError(ret);
        goto _END;
    }

    memcpy(ZN632_INDEX, ZN632_RxBuf + 10, 32);

_END:
    ZN632_ClearRxBuf();
    return ret;
}

/**
  * @brief  获取最小空索引
  */
uint16_t ZN632_GetIndexEmpty(void)
{
    uint16_t index = 0;
    uint16_t i, j;

    for (i = 0; i < sizeof(ZN632_INDEX); i++) {
        for (j = 0; j < 8; j++) {
            if (ZN632_INDEX[i] & (0x1 << j)) {
                index++;
            } else {
                return index;
            }
        }
    }
    return ZN632_INDEX_MAX;
}

/**
  * @brief  标记索引已占用
  */
void ZN632_SetIndex(uint16_t uIndex)
{
    if (uIndex >= ZN632_INDEX_MAX) return;
    ZN632_INDEX[uIndex / 8] |= (0x1 << (uIndex % 8));
}

/**
  * @brief  清除索引标记
  */
void ZN632_UnsetIndex(uint16_t uIndex)
{
    if (uIndex >= ZN632_INDEX_MAX) return;
    ZN632_INDEX[uIndex / 8] &= ~(0x1 << (uIndex % 8));
}

/**
  * @brief  获取指纹图像
  */
int16_t ZN632_GetImage(void)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[6] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x03;
    cmd[3] = CMD_GetImage;

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3];
    cmd[4] = temp >> 8;
    cmd[5] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 6);
    ZN632_DELAY_MS(500);

    ret = ZN632_CheckAck();
    if (ret != 0) ZN632_ShowError(ret);
    ZN632_ClearRxBuf();
    return ret;
}

/**
  * @brief  生成指纹特征
  * @param  BufferID: 缓冲区号(1或2)
  */
int16_t ZN632_GenChar(uint8_t BufferID)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[7] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x04;
    cmd[3] = CMD_GenChar;
    cmd[4] = BufferID;

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3] + cmd[4];
    cmd[5] = temp >> 8;
    cmd[6] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 7);
    ZN632_DELAY_MS(500);

    ret = ZN632_CheckAck();
    if (ret != 0) ZN632_ShowError(ret);
    ZN632_ClearRxBuf();
    return ret;
}

/**
  * @brief  合并特征生成模板
  */
int16_t ZN632_RegModel(void)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[6] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x03;
    cmd[3] = CMD_RegModel;

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3];
    cmd[4] = temp >> 8;
    cmd[5] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 6);
    ZN632_DELAY_MS(500);

    ret = ZN632_CheckAck();
    if (ret != 0) ZN632_ShowError(ret);
    ZN632_ClearRxBuf();
    return ret;
}

/**
  * @brief  储存模板到指纹库
  * @param  BufferID: 缓冲区号
  * @param  PageID: 指纹库位置号(0~239)
  */
int16_t ZN632_StoreChar(uint8_t BufferID, uint16_t PageID)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[9] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x06;
    cmd[3] = CMD_StoreChar;
    cmd[4] = BufferID;
    cmd[5] = PageID >> 8;
    cmd[6] = PageID;

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3] + cmd[4] + cmd[5] + cmd[6];
    cmd[7] = temp >> 8;
    cmd[8] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 9);
    ZN632_DELAY_MS(300);

    ret = ZN632_CheckAck();
    if (ret != 0) ZN632_ShowError(ret);
    ZN632_ClearRxBuf();
    return ret;
}

/**
  * @brief  高速搜索指纹库
  * @param  BufferID: 缓冲区号
  * @param  pID: 返回匹配到的模板ID
  * @param  pScore: 返回匹配分数
  */
int16_t ZN632_HighSpeedSearch(uint8_t BufferID, uint16_t *pID, uint16_t *pScore)
{
    uint16_t temp;
    int16_t  ret;
    uint8_t  cmd[11] = {0};

    cmd[0] = 0x01;
    cmd[1] = 0x00;
    cmd[2] = 0x08;
    cmd[3] = CMD_HighSpeedSearch;
    cmd[4] = BufferID;
    cmd[5] = 0;                     // StartPage 高字节
    cmd[6] = 0;                     // StartPage 低字节
    cmd[7] = ZN632_INDEX_MAX >> 8;  // EndPage 高字节
    cmd[8] = ZN632_INDEX_MAX;       // EndPage 低字节

    temp = cmd[0] + cmd[1] + cmd[2] + cmd[3] + cmd[4] + cmd[5] + cmd[6] + cmd[7] + cmd[8];
    cmd[9]  = temp >> 8;
    cmd[10] = temp;

    ZN632_SendHead();
    ZN632_SendData(cmd, 11);
    ZN632_DELAY_MS(300);

    ret = ZN632_CheckAck();
    if (ret != 0) {
        // 错误信息由调用者决定是否打印
        goto _END;
    }

    *pID    = ((uint16_t)ZN632_RxBuf[10] << 8) | ZN632_RxBuf[11];
    *pScore = ((uint16_t)ZN632_RxBuf[12] << 8) | ZN632_RxBuf[13];

_END:
    ZN632_ClearRxBuf();
    return ret;
}

/* ================================================================
 * 错误信息显示
 * ================================================================ */

static void ZN632_ShowError(uint16_t code)
{
    switch (code) {
    case 0x00: printf("OK\r\n"); break;
    case 0x01: printf("Error: Packet receive error\r\n"); break;
    case 0x02: printf("Error: No finger detected\r\n"); break;
    case 0x03: printf("Error: Image capture failed\r\n"); break;
    case 0x06: printf("Error: Image too messy\r\n"); break;
    case 0x07: printf("Error: Too few feature points\r\n"); break;
    case 0x08: printf("Error: Finger not match\r\n"); break;
    case 0x09: printf("Error: Finger not found in library\r\n"); break;
    case 0x0A: printf("Error: Feature merge failed\r\n"); break;
    case 0x0B: printf("Error: PageID out of range\r\n"); break;
    case 0x15: printf("Error: No valid image in buffer\r\n"); break;
    case 0x18: printf("Error: Flash read/write error\r\n"); break;
    case 0x1F: printf("Error: Library full\r\n"); break;
    default:   printf("Error: Unknown code 0x%02X\r\n", code); break;
    }
}

/* ================================================================
 * 功能流程
 * ================================================================ */

/**
  * @brief  阻塞获取手指图像，可被 g_uExitToChange 中断
  *         加入重试延时，避免刷屏式错误消息
  */
static int8_t FPR_GetImage(void)
{
    uint16_t retry = 0;

    while (1) {
        if (ZN632_GetImage() == 0) {
            printf("Get One Finger\r\n");
            return 0;
        }

        if (g_uExitToChange == 1) {
            g_uExitToChange = 0;
            return -1;
        }

        retry++;
        ZN632_DELAY_MS(200);  // 避免频繁轮询刷屏

        // 每10次重试(~2秒)打印一次提示
        if (retry % 10 == 0) {
            printf("Waiting for finger...\r\n");
        }
    }
}

/**
  * @brief  录入指纹流程
  *         采集两次 → 去重检查 → 合并模板 → 存储
  */
void FPR_AddFinger(void)
{
    int16_t  ret;
    uint16_t uID    = 0;
    uint16_t uScore = 0;
    uint8_t  uStep  = 1;

    while (uStep <= 2) {
        printf("Put Finger On Sensor: Step %d\r\n", uStep);

        ret = FPR_GetImage();
        if (ret != 0) return;

        ret = ZN632_GenChar(uStep);
        if (ret != 0) continue;

        // 去重：检查是否已录入
        ret = ZN632_HighSpeedSearch(uStep, &uID, &uScore);
        if (ret == 0) {
            printf("Finger Already Registered (ID:%d), Try Another\r\n", uID);
            continue;
        }
        // ret == 0x09 (Finger not found) 是正常的，表示未录入过

        uStep++;
    }

    // 合并特征生成模板
    ret = ZN632_RegModel();
    if (ret != 0) return;

    // 获取空位并存储
    uID = ZN632_GetIndexEmpty();
    ret = ZN632_StoreChar(2, uID);
    if (ret != 0) return;

    ZN632_SetIndex(uID);
    printf("Add Finger OK, ID:%d\r\n", uID);
}

/**
  * @brief  指纹比对（识别）流程
  */
void FPR_MatchFinger(void)
{
    int16_t  temp;
    uint16_t uID    = 0;
    uint16_t uScore = 0;

    printf("Put Finger On Sensor\r\n");

    temp = FPR_GetImage();
    if (temp != 0) return;

    temp = ZN632_GenChar(1);
    if (temp != 0) return;

    temp = ZN632_HighSpeedSearch(1, &uID, &uScore);
    if (temp != 0) {
        printf("Finger NOT Match\r\n");
        return;
    }

    printf("Finger Match, ID:%d, Score:%d\r\n", uID, uScore);
}
