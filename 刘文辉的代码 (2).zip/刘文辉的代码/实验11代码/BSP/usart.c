#include <stdio.h>
#include "usart.h"

/* ================================================================
 * UART2 接收环形缓冲区
 * ================================================================ */
#define UART2_RX_BUF_SIZE  64
static volatile uint8_t  UART2_RxBuf[UART2_RX_BUF_SIZE];
static volatile uint16_t UART2_RxHead = 0;   // 中断写入位置
static volatile uint16_t UART2_RxTail = 0;   // 主循环读取位置

/* ================================================================
 * UART2 初始化 (PA2-TX, PA3-RX)
 * ================================================================ */
void UART2_Init(u32 bound)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef  NVIC_InitStructure;

    // 时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    // PA2-TX, PA3-RX 复用为 USART2
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // USART2 参数
    USART_InitStructure.USART_BaudRate            = bound;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);

    // 使能接收中断
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel                   = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART2, ENABLE);
}

/* ================================================================
 * printf 重定向到 USART2
 * ================================================================ */
int fputc(int ch, FILE *f)
{
    USART_SendData(USART2, (uint8_t)ch);
    while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    return ch;
}

/* ================================================================
 * USART2 中断处理: 接收数据 → 环形缓冲区 → 回显
 * ================================================================ */
void USART2_IRQHandler(void)
{
    uint8_t  ch;
    uint16_t next;

    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        ch = USART_ReceiveData(USART2);

        // 存入环形缓冲区
        next = UART2_RxHead + 1;
        if (next >= UART2_RX_BUF_SIZE) next = 0;
        if (next != UART2_RxTail) {
            UART2_RxBuf[UART2_RxHead] = ch;
            UART2_RxHead = next;
        }

        // 回显
        USART_SendData(USART2, ch);
        while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);

        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
}

/* ================================================================
 * 从环形缓冲区读取一个字符 (阻塞等待)
 * ================================================================ */
char UART2_GetChar(void)
{
    uint8_t ch;

    // 等待缓冲区有数据
    while (UART2_RxHead == UART2_RxTail);

    ch = UART2_RxBuf[UART2_RxTail];
    UART2_RxTail++;
    if (UART2_RxTail >= UART2_RX_BUF_SIZE) {
        UART2_RxTail = 0;
    }

    return (char)ch;
}
