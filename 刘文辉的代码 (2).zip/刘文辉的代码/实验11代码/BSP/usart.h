#ifndef __USART_H__
#define __USART_H__

#include "stm32f4xx.h"

void UART2_Init(u32 bound);
char UART2_GetChar(void);

#endif
