#include "stm32f4xx.h"
#include "fpr_zn632.h"
#include "delay.h"
#include "usart.h"

/**
  * @brief  打印菜单
  */
void FPR_Usage(void)
{
    printf("\r\n========== Menu ==========\r\n");
    printf("1 Add New Finger\r\n");
    printf("2 Match Finger\r\n");
    printf("==========================\r\n");
    printf("Select: ");
}

/**
  * @brief  主函数
  */
int main(void)
{
    char ch = 0;

    delay_init(168);              // 系统时钟168MHz，初始化延时
    UART2_Init(115200);           // 调试串口初始化
    printf("\r\nSystem Booting...\r\n");

    FPR_Init(57600);              // 指纹模块初始化（波特率57600）
    printf("FPR Init OK\r\n");

    if (ZN632_VryPwd() == 0) {   // 验证模块密码
        printf("Passwrd OK\r\n");
    } else {
        printf("VryPwd Fail (continuing)\r\n");
    }

    if (ZN632_ReadIndexTable() == 0) {  // 读取指纹索引表
        printf("ReadIndexTable OK\r\n");
    } else {
        printf("ReadIndexTable Fail (continuing)\r\n");
    }

    while (1) {
        FPR_Usage();
        ch = UART2_GetChar();     // 使用环形缓冲区读取

        // 过滤回车换行等空白字符
        if (ch == '\r' || ch == '\n') continue;

        printf("%c\r\n", ch);     // 回显确认
        switch (ch) {
        case '1':
            FPR_AddFinger();      // 录入指纹
            break;
        case '2':
            FPR_MatchFinger();    // 比对指纹
            break;
        default:
            printf("Invalid: %c\r\n", ch);
            break;
        }
    }
}
