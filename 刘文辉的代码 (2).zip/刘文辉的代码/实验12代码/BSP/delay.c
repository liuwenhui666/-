#include "delay.h"

static u8  fac_us = 0;    //us延时倍乘数
static u16 fac_ms = 0;    //ms延时倍乘数

/*
 * 延时初始化
 * SYSCLK: 系统时钟频率，单位MHz
 */
void delay_init(u8 SYSCLK)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);  //选择外部时钟 HCLK/8
    fac_us = SYSCLK / 8;                                    //SYSCLK的1/8
    fac_ms = (u16)fac_us * 1000;                            //1ms需要计数的数目
}

/*
 * 微秒级延时
 * nus: 延时的微秒数
 */
void delay_us(u32 nus)
{
    u32 temp;
    SysTick->LOAD = nus * fac_us;         //时间加载
    SysTick->VAL  = 0x00;                 //清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;  //开始倒数
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));  //等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;        //关闭计数器
    SysTick->VAL  = 0x00;                             //清空计数器
}

/*
 * 毫秒级延时
 * nms: 延时的毫秒数
 */
void delay_ms(u16 nms)
{
    u32 temp;
    SysTick->LOAD = (u32)nms * fac_ms;    //时间加载
    SysTick->VAL  = 0x00;                 //清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;  //开始倒数
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));  //等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;        //关闭计数器
    SysTick->VAL  = 0x00;                             //清空计数器
}
