#include <stdio.h>
#include "stm32f4xx.h"
#include "nfc_pn532.h"
#include "usart.h"
#include "delay.h"

#define TEST_SIZE 16
#define TEST_BLOCK 2    /* 测试读写的数据块(扇区0的块2，非控制块) */

uint8_t BufRead[TEST_SIZE]  = {0};
uint8_t BufWrite[TEST_SIZE] = {0};

/*
 * 制造16字节递增测试数据用于写入
 */
void make_test_data(void)
{
    uint32_t i = 0;

    printf("Write test data: ");
    for (i = 0; i < TEST_SIZE; i++) {
        BufWrite[i] = i;
        printf("0x%02X ", BufWrite[i]);
    }
    printf("\r\n");
}

/*
 * 检测读取数据与写入数据是否一致
 */
uint8_t check_test_data(void)
{
    uint32_t i = 0;

    printf("Read  test data: ");
    for (i = 0; i < TEST_SIZE; i++) {
        printf("0x%02X ", BufRead[i]);
        if (BufRead[i] != BufWrite[i]) {
            printf("\r\nData mismatch at byte %d! (read 0x%02X != write 0x%02X)\r\n",
                   (int)i, BufRead[i], BufWrite[i]);
            return 0;  /* 校验失败 */
        }
    }
    printf("\r\n");
    return 1;  /* 校验通过 */
}

/*
 * 主程序入口
 * 流程：初始化 -> 自动探测波特率 -> 生成测试数据 -> 循环（寻卡 -> 读写测试）
 */
int main(void)
{
    int8_t rc;

    delay_init(168);           /* 系统时钟168MHz */
    UART2_Init(115200);        /* 调试串口(USART2) */
    delay_ms(100);

    printf("\r\n\r\n");
    printf("========================================\r\n");
    printf("  PN532 NFC Test - QST-AU100 STM32F407\r\n");
    printf("  UART1: PA9(TX) PA10(RX)\r\n");
    printf("========================================\r\n\r\n");

    /*
     * 自动探测波特率并初始化PN532
     * 会依次尝试 115200, 57600, 38400, 19200, 9600
     */
    rc = NFC_InitWithProbe();
    if (rc != 0) {
        printf("\r\n");
        printf("========================================\r\n");
        printf("  PN532 INITIALIZATION FAILED!\r\n");
        printf("  Troubleshooting:\r\n");
        printf("  1. Check jumper cap on [UART1->NFC]\r\n");
        printf("  2. Check NFC module power (3.3V)\r\n");
        printf("  3. Verify PA9/PA10 connections\r\n");
        printf("  4. Try manual baudrate: NFC_Init(XXX)\r\n");
        printf("========================================\r\n");
        while (1) {
            delay_ms(1000);
            printf("PN532 still not responding...\r\n");
        }
    }

    make_test_data();

    printf("\r\n========================================\r\n");
    printf("Place M1 card on NFC antenna area...\r\n");
    printf("Block %d will be read/written for test.\r\n", TEST_BLOCK);
    printf("========================================\r\n\r\n");

    while (1) {
        uint8_t uid[7];
        uint8_t uidLen = 0;

        /* 寻卡 */
        if (PN532_InListPassiveTarget(uid, &uidLen) == 0) {
            printf("\r\n>>> Card found! UID=");
            {
                int i;
                for (i = 0; i < uidLen; i++) printf("%02X", uid[i]);
            }
            printf("\r\n");

            /* 先读取卡片数据 */
            rc = NFC_Read(TEST_BLOCK, BufRead);
            if (rc == 0) {
                printf(">>> Read block %d OK\r\n", TEST_BLOCK);
                if (check_test_data()) {
                    printf(">>> DATA VERIFY: PASS (data matches)\r\n");
                } else {
                    printf(">>> DATA VERIFY: FAIL (writing new data...)\r\n");
                    /* 写入测试数据 */
                    rc = NFC_Write(TEST_BLOCK, BufWrite);
                    if (rc == 0) {
                        printf(">>> Write block %d OK\r\n", TEST_BLOCK);
                        /* 回读验证 */
                        NFC_ClearCardSelected();
                        rc = NFC_Read(TEST_BLOCK, BufRead);
                        if (rc == 0 && check_test_data()) {
                            printf(">>> Write verify: PASS\r\n");
                        } else {
                            printf(">>> Write verify: FAIL\r\n");
                        }
                    }
                }
            } else {
                printf(">>> Read block %d FAILED\r\n", TEST_BLOCK);
            }

            NFC_ClearCardSelected();

            printf(">>> Test complete. Waiting for next card...\r\n\r\n");
            delay_ms(2000);
        }
        delay_ms(300);
    }
}
