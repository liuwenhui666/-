#include "stm32f4xx_it.h"
#include "stm32f4xx.h"

//外部中断处理函数声明
extern void USART1_IRQHandler(void);
extern void USART2_IRQHandler(void);

void NMI_Handler(void) {}

void HardFault_Handler(void)
{
    while (1) {}
}

void MemManage_Handler(void)
{
    while (1) {}
}

void BusFault_Handler(void)
{
    while (1) {}
}

void UsageFault_Handler(void)
{
    while (1) {}
}

void SVC_Handler(void) {}

void DebugMon_Handler(void) {}

void PendSV_Handler(void) {}

void SysTick_Handler(void) {}
