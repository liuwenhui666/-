/**
 * @file    delay.c
 * @brief   延时函数实现
 * @note    基于STM32F407 SysTick实现微秒/毫秒级延时
 *          系统主频168MHz，SysTick时钟源使用系统时钟(HCLK)
 *
 *          DHT11驱动依赖本文件提供的 delay_us / delay_ms 函数，
 *          实验文档中引用了 delay.h 但未给出实现，此处补充完整。
 */

#include "delay.h"

static u8  fac_us = 0;   //us延时倍乘数
static u16 fac_ms = 0;   //ms延时倍乘数

/**
 * @brief  初始化延时模块
 * @note   SysTick时钟源为HCLK(168MHz)，fac_us=168, fac_ms=168000
 */
void delay_init(void)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);  //SysTick时钟源为HCLK
    fac_us = SystemCoreClock / 1000000;               //168
    fac_ms = (u16)fac_us * 1000;                      //168000
}

/**
 * @brief   微秒级延时
 * @param   nus: 延时微秒数 (0~798915)
 * @note    使用SysTick倒计数，nms最大不能超过798915us
 */
void delay_us(u32 nus)
{
    u32 temp;
    SysTick->LOAD = nus * fac_us;
    SysTick->VAL  = 0x00;         //清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;  //开始倒数
    do {
        temp = SysTick->CTRL;
    } while((temp & 0x01) && !(temp & (1 << 16)));  //等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;       //关闭计数器
    SysTick->VAL = 0x00;                              //清空计数器
}

/**
 * @brief   毫秒级延时
 * @param   nms: 延时毫秒数
 * @note    为保证精度，nms较大时通过循环调用delay_us(最大798915us)实现
 */
void delay_ms(u32 nms)
{
    while(nms) {
        if(nms > 798) {
            delay_us(798000);  //798ms
            nms -= 798;
        } else {
            delay_us(nms * 1000);
            nms = 0;
        }
    }
}
