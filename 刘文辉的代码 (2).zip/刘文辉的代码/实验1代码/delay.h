/**
 * @file    delay.h
 * @brief   延时函数头文件
 * @note    基于STM32F407 SysTick实现的微秒/毫秒级延时
 *          DHT11驱动依赖此模块提供 delay_us / delay_ms
 */

#ifndef __DELAY_H__
#define __DELAY_H__

#include "stm32f4xx.h"

/**
 * @brief   初始化延时模块（配置SysTick）
 * @note    系统时钟168MHz，SysTick时钟为168MHz
 */
void delay_init(void);

/**
 * @brief   微秒级延时
 * @param   nus: 延时微秒数（0~798915）
 */
void delay_us(u32 nus);

/**
 * @brief   毫秒级延时
 * @param   nms: 延时毫秒数
 */
void delay_ms(u32 nms);

#endif /* __DELAY_H__ */
