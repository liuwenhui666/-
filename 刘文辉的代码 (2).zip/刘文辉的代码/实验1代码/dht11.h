/**
 * @file    dht11.h
 * @brief   DHT11温湿度传感器对外接口头文件
 * @note    基于STM32F407 GPIO实现，单总线通信协议
 */

#ifndef __DHT11_H__
#define __DHT11_H__

#include "stm32f4xx.h"

/**
 * @brief  DHT11温湿度数据结构体
 */
typedef struct{
    uint8_t  humi_int;      //湿度的整数部分
    uint8_t  humi_deci;     //湿度的小数部分
    uint8_t  temp_int;      //温度的整数部分
    uint8_t  temp_deci;     //温度的小数部分
    uint8_t  check_sum;     //校验和
} DHT11_Data;


/**
 * @brief   DHT11初始化函数
 * @note    配置GPIO时钟，设置引脚为输出模式，初始拉高
 */
void   DHT11_Init( void );

/**
 * @brief   读取DHT11温湿度数据
 * @param   pData: 指向DHT11_Data结构体的指针，用于存储读取结果
 * @retval  0: 读取成功; -1: 读取失败或校验错误
 */
int8_t DHT11_ReadData(DHT11_Data *pData);

#endif /* __DHT11_H__ */
