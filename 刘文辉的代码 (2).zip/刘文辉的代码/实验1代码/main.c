/**
 * @file    main.c
 * @brief   DHT11温湿度传感器测试主程序
 * @note    合并实验文档代码 7-3-1 / 7-3-2
 *          循环读取DHT11温湿度数据并通过UART2调试串口输出
 */

#include <stdio.h>
#include "stm32f4xx.h"
#include "dht11.h"
#include "usart.h"
#include "delay.h"

/**
  * @brief  主函数
  * @param  无
  * @retval 无
  */
int main(void)
{
    DHT11_Data Data;

    //初始化延时模块（SysTick）
    delay_init();

    //初始化UART2调试串口，波特率115200
    UART2_Init(115200);

    //初始化DHT11
    DHT11_Init();
    printf("DHT11 Init OK\r\n");

    delay_ms(1000);

    while(1) {
        if(DHT11_ReadData(&Data) == 0) {
            printf("HUMI:%d.%d_TEMP:%d.%d\r\n", \
                   Data.humi_int, Data.humi_deci, Data.temp_int, Data.temp_deci);
        } else {
            printf("Read DHT11 ERROR!\r\n");
        }
        delay_ms(10000);
    }
}
