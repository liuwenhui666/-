/**
 * @file    usart.h
 * @brief   STM32 UART2调试串口对外接口头文件
 */

#ifndef __USART_H__
#define __USART_H__

#include "stm32f4xx.h"

/**
 * @brief   UART2初始化函数
 * @param   bound: 波特率（如115200）
 */
void UART2_Init(u32 bound);

/**
 * @brief   发送一个字节
 * @param   pUSARTx: USART外设指针
 * @param   ch:      待发送的字节
 */
void UART_SendByte(USART_TypeDef *pUSARTx, uint8_t ch);

/**
 * @brief   发送字符串
 * @param   pUSARTx: USART外设指针
 * @param   str:     待发送的字符串
 */
void UART_SendString(USART_TypeDef *pUSARTx, char *str);

/**
 * @brief   发送一个16位数据（高字节先行）
 * @param   pUSARTx: USART外设指针
 * @param   ch:      待发送的16位数据
 */
void UART_SendHalfWord(USART_TypeDef *pUSARTx, uint16_t ch);

#endif /* __USART_H__ */
