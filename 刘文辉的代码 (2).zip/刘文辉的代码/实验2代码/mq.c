#include "stm32f4xx.h"
#include "mq.h"
#include "delay.h"

#define MQ_ADC  ADC1

/**
  * @brief  MQ2 GPIO 配置 — PC2 模拟输入
  * @param  无
  * @retval 无
  */
void MQ_GPIO_Config(void)
{
    GPIO_InitTypeDef GPIO_InitX;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);

    /* 配置为模拟输入 */
    GPIO_InitX.GPIO_Pin  = GPIO_Pin_2;
    GPIO_InitX.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_InitX.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOC, &GPIO_InitX);
}

/**
  * @brief  MQ2 ADC 配置 — ADC1 独立模式 / 12bit / 软件触发
  * @param  无
  * @retval 无
  */
void MQ_ADC_Config(void)
{
    ADC_InitTypeDef ADC_InitX;
    ADC_CommonInitTypeDef ADC_CommonInitX;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    /* Common 参数配置 */
    ADC_CommonInitX.ADC_Mode              = ADC_Mode_Independent;
    ADC_CommonInitX.ADC_Prescaler         = ADC_Prescaler_Div4;
    ADC_CommonInitX.ADC_DMAAccessMode     = ADC_DMAAccessMode_Disabled;
    ADC_CommonInitX.ADC_TwoSamplingDelay  = ADC_TwoSamplingDelay_20Cycles;
    ADC_CommonInit(&ADC_CommonInitX);

    /* ADC Init 参数配置 */
    ADC_StructInit(&ADC_InitX);
    ADC_InitX.ADC_Resolution           = ADC_Resolution_12b;
    ADC_InitX.ADC_ScanConvMode         = DISABLE;
    ADC_InitX.ADC_ContinuousConvMode   = DISABLE;
    ADC_InitX.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    ADC_InitX.ADC_ExternalTrigConv     = ADC_ExternalTrigConv_T1_CC1;
    ADC_InitX.ADC_DataAlign            = ADC_DataAlign_Right;
    ADC_InitX.ADC_NbrOfConversion      = 1;
    ADC_Init(MQ_ADC, &ADC_InitX);

    /* 配置 ADC 通道：通道12，转换顺序第1，采样周期28 */
    ADC_RegularChannelConfig(MQ_ADC, ADC_Channel_12, 1, ADC_SampleTime_28Cycles);

    ADC_Cmd(MQ_ADC, ENABLE);
}

/**
  * @brief  MQ2 初始化
  * @param  无
  * @retval 无
  */
void MQ_Init(void)
{
    MQ_GPIO_Config();
    MQ_ADC_Config();
}

/**
  * @brief  读取 MQ2 ADC 转换值
  * @param  无
  * @retval 12bit ADC 值 (0-4095)，超时返回 0
  */
uint16_t MQ_ReadValue(void)
{
    uint32_t uTimeout = 100;
    ADC_SoftwareStartConv(MQ_ADC);  /* 软件触发ADC转换 */

    /* 判断是否采样转换完毕 */
    while (ADC_GetFlagStatus(MQ_ADC, ADC_FLAG_EOC) != SET) {
        if (uTimeout--) { return 0; }
        delay_ms(1);
    }
    ADC_ClearFlag(MQ_ADC, ADC_FLAG_EOC);  /* 清除标志位 */

    return ADC_GetConversionValue(MQ_ADC);
}