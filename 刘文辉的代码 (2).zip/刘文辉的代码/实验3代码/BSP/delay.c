#include "delay.h"

/**
 * @brief  Systick微秒级精确延时
 * @param  us : 延时的微秒数
 * @note   使用前需在main中调用 SysTick_Config(SystemCoreClock/1000) 初始化Systick
 *         Systick计时频率 = SystemCoreClock = 168MHz
 */
void systick_delay_us(uint32_t us)
{
    uint32_t ticks;
    uint32_t told, tnow, reload, tcnt = 0;

    reload = SysTick->LOAD;                          // 获取重装载寄存器值
    ticks  = us * (SystemCoreClock / 1000000);       // 计算需要的总计数值
    told   = SysTick->VAL;                           // 获取当前数值寄存器值

    while (1)
    {
        tnow = SysTick->VAL;
        if (tnow == told)
        {
            continue;   // 没有差值，不需处理
        }

        if (tnow < told)
        {
            tcnt += told - tnow;          // 未计到0
        }
        else
        {
            tcnt += reload - tnow + told; // 已计到0并重新计数
        }

        told = tnow;
        if (tcnt >= ticks)
        {
            break;
        }
    }
}
