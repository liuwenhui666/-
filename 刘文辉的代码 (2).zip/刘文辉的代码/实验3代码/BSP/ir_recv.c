#include "ir_recv.h"
#include "usart.h"
#include <stdio.h>

/* 红外接收使用PB9引脚，TIM4_CH4输入捕获 */
#define IR_RECV_GPIO_PORT       GPIOB
#define IR_RECV_GPIO_PIN        GPIO_Pin_9
#define IR_RECV_GPIO_PINSRC     GPIO_PinSource9
#define IR_RECV_TIM             TIM4
#define IR_RECV_TIM_CH          TIM_Channel_4
#define IR_RECV_IRQn            TIM4_IRQn

/* NEC协议时间阈值（单位us） */
#define NEC_LEADER_MIN          4000    // 引导码低电平最小时间
#define NEC_LEADER_MAX          5000    // 引导码低电平最大时间
#define NEC_REPEAT_MIN          2000    // 重复码低电平最小时间
#define NEC_REPEAT_MAX          2500    // 重复码低电平最大时间
#define NEC_BIT0_THRESHOLD      800     // 位0与位1的分界阈值
#define NEC_BIT_MAX             2500    // 位数据最大时间

/* 全局变量 */
IR_FrameTypeDef g_IR_Frame;
static volatile uint8_t  g_IR_NewFrame  = 0;
static volatile uint32_t g_IR_LastTime  = 0;
static volatile uint8_t  g_IR_BitCount  = 0;
static volatile uint32_t g_IR_Data      = 0;
static volatile IR_StateTypeDef g_IR_State = IR_STATE_IDLE;

/**
 * @brief  红外接收初始化
 *         PB9 → TIM4_CH4，输入捕获模式
 */
void IR_Recv_Init(void)
{
    GPIO_InitTypeDef        GPIO_InitStruct;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
    TIM_ICInitTypeDef       TIM_ICInitStruct;
    NVIC_InitTypeDef        NVIC_InitStruct;

    // 使能时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

    // PB9 GPIO配置
    GPIO_InitStruct.GPIO_Pin   = IR_RECV_GPIO_PIN;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(IR_RECV_GPIO_PORT, &GPIO_InitStruct);

    GPIO_PinAFConfig(IR_RECV_GPIO_PORT, IR_RECV_GPIO_PINSRC, GPIO_AF_TIM4);

    // TIM4时基配置（1us计数）
    // TIM4时钟 = 2*APB1 = 84MHz，Prescaler=84-1 → 1MHz = 1us
    TIM_TimeBaseStruct.TIM_Period        = 0xFFFF;
    TIM_TimeBaseStruct.TIM_Prescaler     = 84 - 1;
    TIM_TimeBaseStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStruct.TIM_CounterMode   = TIM_CounterMode_Up;
    TIM_TimeBaseInit(IR_RECV_TIM, &TIM_TimeBaseStruct);

    // 输入捕获配置（下降沿捕获）
    TIM_ICInitStruct.TIM_Channel     = IR_RECV_TIM_CH;
    TIM_ICInitStruct.TIM_ICPolarity  = TIM_ICPolarity_Falling;
    TIM_ICInitStruct.TIM_ICSelection = TIM_ICSelection_DirectTI;
    TIM_ICInitStruct.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    TIM_ICInitStruct.TIM_ICFilter    = 0x0F;
    TIM_ICInit(IR_RECV_TIM, &TIM_ICInitStruct);

    // 使能捕获中断
    TIM_ITConfig(IR_RECV_TIM, TIM_IT_CC4, ENABLE);

    // NVIC配置
    NVIC_InitStruct.NVIC_IRQChannel                   = IR_RECV_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority        = 0;
    NVIC_InitStruct.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    TIM_Cmd(IR_RECV_TIM, ENABLE);
}

/**
 * @brief  TIM4中断处理函数：输入捕获解析NEC协议
 */
void TIM4_IRQHandler(void)
{
    uint32_t duration;

    if (TIM_GetITStatus(IR_RECV_TIM, TIM_IT_CC4) != RESET)
    {
        TIM_ClearITPendingBit(IR_RECV_TIM, TIM_IT_CC4);

        uint32_t capture = TIM_GetCapture4(IR_RECV_TIM);
        duration = capture - g_IR_LastTime;
        g_IR_LastTime = capture;

        switch (g_IR_State)
        {
            case IR_STATE_IDLE:
                g_IR_State   = IR_STATE_LEADER;
                g_IR_BitCount = 0;
                g_IR_Data     = 0;
                break;

            case IR_STATE_LEADER:
                if (duration > NEC_LEADER_MIN && duration < NEC_LEADER_MAX)
                {
                    g_IR_State = IR_STATE_DATA;  // 引导码正确，开始接收数据
                }
                else if (duration > NEC_REPEAT_MIN && duration < NEC_REPEAT_MAX)
                {
                    g_IR_State = IR_STATE_REPEAT; // 重复码
                }
                else
                {
                    g_IR_State = IR_STATE_IDLE;   // 异常，回到空闲
                }
                break;

            case IR_STATE_DATA:
                if (duration > 0 && duration < NEC_BIT_MAX)
                {
                    g_IR_Data >>= 1;
                    if (duration > NEC_BIT0_THRESHOLD)
                    {
                        g_IR_Data |= 0x80000000;  // 位1
                    }
                    g_IR_BitCount++;

                    if (g_IR_BitCount >= 32)
                    {
                        // 32位数据接收完成
                        g_IR_Frame.addr     = (uint8_t)(g_IR_Data);
                        g_IR_Frame.addr_inv = (uint8_t)(g_IR_Data >> 8);
                        g_IR_Frame.code     = (uint8_t)(g_IR_Data >> 16);
                        g_IR_Frame.code_inv = (uint8_t)(g_IR_Data >> 24);

                        // 验证数据正确性
                        if ((g_IR_Frame.addr == (uint8_t)(~g_IR_Frame.addr_inv)) &&
                            (g_IR_Frame.code == (uint8_t)(~g_IR_Frame.code_inv)))
                        {
                            g_IR_NewFrame = 1;
                            g_IR_State    = IR_STATE_COMPLETE;
                        }
                        else
                        {
                            g_IR_State = IR_STATE_IDLE;
                        }
                    }
                }
                else
                {
                    g_IR_State = IR_STATE_IDLE;
                }
                break;

            case IR_STATE_REPEAT:
                g_IR_State = IR_STATE_IDLE;
                break;

            case IR_STATE_COMPLETE:
                g_IR_State = IR_STATE_IDLE;
                break;

            default:
                g_IR_State = IR_STATE_IDLE;
                break;
        }
    }
}

/**
 * @brief  红外接收主循环处理函数
 *         检测并打印新接收到的数据帧
 */
void IR_Recv(void)
{
    if (g_IR_NewFrame)
    {
        g_IR_NewFrame = 0;
        printf("IRRecv: addr=%d, addr_inv=%d, code=%d, code_inv=%d\r\n",
               g_IR_Frame.addr,
               g_IR_Frame.addr_inv,
               g_IR_Frame.code,
               g_IR_Frame.code_inv);
    }
}

/**
 * @brief  查询是否有新帧
 * @return 1:有新帧, 0:无新帧
 */
uint8_t IR_Recv_NewFrame(void)
{
    return g_IR_NewFrame;
}
