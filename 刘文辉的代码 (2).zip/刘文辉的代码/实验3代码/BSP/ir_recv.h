#ifndef __IR_RECV_H__
#define __IR_RECV_H__

#include "stm32f4xx.h"

/* NEC红外遥控数据帧结构 */
typedef struct
{
    uint8_t addr;       // 地址码
    uint8_t addr_inv;   // 地址反码
    uint8_t code;       // 键码
    uint8_t code_inv;   // 键码反码
} IR_FrameTypeDef;

/* 红外接收状态 */
typedef enum
{
    IR_STATE_IDLE = 0,       // 空闲
    IR_STATE_LEADER,         // 接收引导码
    IR_STATE_DATA,           // 接收数据
    IR_STATE_REPEAT,         // 重复码
    IR_STATE_COMPLETE        // 接收完成
} IR_StateTypeDef;

void IR_Recv_Init(void);
void IR_Recv(void);
uint8_t IR_Recv_NewFrame(void);

extern IR_FrameTypeDef g_IR_Frame;

#endif /* __IR_RECV_H__ */
