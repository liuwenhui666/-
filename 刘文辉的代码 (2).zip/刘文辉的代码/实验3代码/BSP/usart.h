#ifndef __USART_H__
#define __USART_H__

#include "stm32f4xx.h"
#include <stdio.h>

void UART2_Init(uint32_t baudrate);

#endif /* __USART_H__ */
