/**
 * @file    main.c
 * @brief   IR红外遥控发送实验 —— 自发自收测试
 * @note    AU100开发板-STM32F407
 *          红外发送: PB8 (TIM10_CH1)  红外接收: PB9 (TIM4_CH4)
 *          调试串口: UART2 (PA2-TX, PA3-RX) @ 115200bps
 */

#include <stdio.h>
#include "stm32f4xx.h"
#include "usart.h"
#include "ir_recv.h"
#include "ir_send.h"

#define DELAY_MS_COUNT  4000    // 延时计数（配合主循环实现ms级计时）
#define SEND_INTERVAL   10000   // 每10秒发送一次（单位ms）

int main(void)
{
    uint32_t i        = 0;
    uint32_t uMSCount = 0;

    /* 初始化Systick用于精确延时 */
    SysTick_Config(SystemCoreClock / 1000);

    /* 初始化调试串口 */
    UART2_Init(115200);

    /* 初始化红外接收模块 */
    IR_Recv_Init();
    printf("IR Recv Init OK\r\n");

    /* 初始化红外发送模块 */
    IR_Send_Init();
    printf("IR Send Init OK\r\n");

    printf("===== IR Send Test Start =====\r\n");

    while (1)
    {
        /* 检测是否接收到红外数据 */
        IR_Recv();

        /* 每隔10秒发送一次红外遥控数据 */
        if (uMSCount >= SEND_INTERVAL)
        {
            printf("IRSend: addr=1, code=123\r\n");
            IR_Send(1, 123);
            uMSCount = 0;
        }

        /* 毫秒延时计数（非阻塞） */
        if (i >= DELAY_MS_COUNT)
        {
            uMSCount++;
            i = 0;
        }
        else
        {
            i++;
        }
    }
}
