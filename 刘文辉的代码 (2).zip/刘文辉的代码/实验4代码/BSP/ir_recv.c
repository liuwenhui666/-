#include <stdio.h>
#include "stm32f4xx.h"
#include "delay.h"
#include "ir_recv.h"

#define IR_RECV_TIM   TIM9

/* 遥控器接收状态 */
/* Bit[7]: 收到了引导码标志 */
/* Bit[6]: 得到了一个按键的所有信息 */
/* Bit[5]: 保留 */
/* Bit[4]: 标记是否收到第一个上升沿 */
uint8_t IRState  = 0;
#define IR_STATE_LEAD_OK  0x80   /* 标记是否已接收到前导码 */
#define IR_STATE_DATA_OK  0x40   /* 标记此键值是否已接收完 */
#define IR_STATE_UP_OK    0x10   /* 标记是否收到第一个上升沿 */

uint32_t  CapValue = 0;   /* 捕获信号时的时长 */
uint32_t  IRCount  = 0;   /* 按键按下的次数 */
uint32_t  IRData   = 0;   /* 红外接收到的完整数据 */

static void IR_GPIO_Init(void);
static void IR_TIM_Init(void);

/**
  * @brief  IR接收模块初始化
  */
void IR_Recv_Init(void)
{
    IR_GPIO_Init();
    IR_TIM_Init();
}

/**
  * @brief  IR接收GPIO初始化 (PE5 -> TIM9_CH1)
  */
static void IR_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);

    /* PE5: TIM9_CH1 */
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_5;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIOE, GPIO_PinSource5, GPIO_AF_TIM9);
}

/**
  * @brief  IR接收TIMER初始化 (TIM9 输入捕获)
  */
static void IR_TIM_Init(void)
{
    NVIC_InitTypeDef NVIC_InitStruct;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStruct;
    TIM_ICInitTypeDef  TIM_ICInitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9, ENABLE);

    /* 时基配置: 计数频率1MHz, 周期10ms */
    TIM_TimeBaseStruct.TIM_Period        = 10000;            /* 自动重装载值, 周期10ms */
    TIM_TimeBaseStruct.TIM_Prescaler     = 167;              /* 预分频器, 1MHz计数频率, 1us加1 */
    TIM_TimeBaseStruct.TIM_ClockDivision = TIM_CKD_DIV1;     /* 时钟分割 */
    TIM_TimeBaseStruct.TIM_CounterMode   = TIM_CounterMode_Up;
    TIM_TimeBaseInit(IR_RECV_TIM, &TIM_TimeBaseStruct);

    /* 输入捕获通道1配置 */
    TIM_ICInitStruct.TIM_Channel     = TIM_Channel_1;
    TIM_ICInitStruct.TIM_ICPolarity  = TIM_ICPolarity_Rising;   /* 上升沿捕获 */
    TIM_ICInitStruct.TIM_ICSelection = TIM_ICSelection_DirectTI; /* 直接映射 */
    TIM_ICInitStruct.TIM_ICPrescaler = TIM_ICPSC_DIV1;          /* 不分频 */
    TIM_ICInitStruct.TIM_ICFilter    = 0x03;                    /* 8个定时器时钟周期滤波 */
    TIM_ICInit(IR_RECV_TIM, &TIM_ICInitStruct);

    /* 允许更新中断和CC1捕获中断 */
    TIM_ITConfig(TIM9, TIM_IT_Update | TIM_IT_CC1, ENABLE);
    TIM_Cmd(IR_RECV_TIM, ENABLE);

    /* NVIC中断配置 */
    NVIC_InitStruct.NVIC_IRQChannel                   = TIM1_BRK_TIM9_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority        = 3;
    NVIC_InitStruct.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
}

/**
  * @brief  TIM1_BRK_TIM9 中断处理函数
  *         处理输入捕获中断(CC1)和定时器溢出中断(Update)
  */
void TIM1_BRK_TIM9_IRQHandler(void)
{
    /* ---- 输入捕获中断 (上升沿捕获) ---- */
    if (TIM_GetITStatus(IR_RECV_TIM, TIM_IT_CC1) != RESET)
    {
        TIM_ClearITPendingBit(IR_RECV_TIM, TIM_IT_CC1);
        TIM_SetCounter(IR_RECV_TIM, 0);     /* 清空计数器, 防止溢出 */

        /* 第一次上升沿只标记新信号开始 */
        if (!(IRState & IR_STATE_UP_OK))
        {
            IRState |= IR_STATE_UP_OK;
            return;
        }

        /* 两次上升沿间隔 - 560us脉冲 = 高电平时长 */
        CapValue = TIM_GetCapture1(IR_RECV_TIM) - 560;

        if (CapValue > 300 && CapValue < 800)
        {
            /* 数据位0, 标准值560us, LSB先发 */
            IRData >>= 1;
        }
        else if (CapValue > 1400 && CapValue < 1800)
        {
            /* 数据位1, 标准值1680us, LSB先发 */
            IRData >>= 1;
            IRData |= 0x80000000;
        }
        else if (CapValue > 2200 && CapValue < 2600)
        {
            /* 重复码, 标准值2.5ms */
            IRCount++;
        }
        else if (CapValue > 4200 && CapValue < 5000)
        {
            /* 引导码, 标准值4.5ms */
            IRData  = 0;
            IRState |= IR_STATE_LEAD_OK;
            IRCount = 0;
        }
    }

    /* ---- 定时器溢出中断 (数据接收完毕) ---- */
    if (TIM_GetITStatus(IR_RECV_TIM, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(IR_RECV_TIM, TIM_IT_Update);

        if (IRState & IR_STATE_LEAD_OK)
        {
            IRState &= ~IR_STATE_UP_OK;    /* 取消上升沿捕获标记 */
            IRState &= ~IR_STATE_LEAD_OK;  /* 清除引导码标记 */
            IRState |= IR_STATE_DATA_OK;   /* 标记完成一次键值采集 */

            printf("IRRecv:[%lX]\r\n", IRData);
        }
    }
}

/**
  * @brief  默认键码处理回调 (弱函数, 可由应用层重写)
  */
__attribute__((weak)) void IR_Rece_Proc(uint16_t addr, uint8_t code)
{
    printf("IRRecv:addr:%d, code:%d\r\n", addr, code);
}

/**
  * @brief  红外接收任务处理 (主循环调用)
  *         解析NEC协议数据, 校验并调用键码处理函数
  */
void IR_Recv(void)
{
    uint16_t addr = 0;
    uint8_t byte1, byte2, byte3, byte4;

    if (!(IRState & IR_STATE_DATA_OK))
    {
        return;
    }

    IRState &= ~IR_STATE_DATA_OK;

    byte1 = (uint8_t)(IRData);        /* 地址码 */
    byte2 = (uint8_t)(IRData >> 8);   /* 地址反码 */
    byte3 = (uint8_t)(IRData >> 16);  /* 键码 */
    byte4 = (uint8_t)(IRData >> 24);  /* 键码反码 */
    IRData = 0;

    /* 校验键码: 键码与键码反码应互为反码 */
    if (byte3 != (uint8_t)~byte4)
    {
        return;
    }

    /* 地址码处理: 非反码关系则为扩展协议(16位地址) */
    if (byte1 != (uint8_t)~byte2)
    {
        addr = (uint16_t)(byte1) | ((uint16_t)byte2 << 8);
    }
    else
    {
        addr = byte1;
    }

    IR_Rece_Proc(addr, byte3);
}
