#ifndef __IR_RECV_H__
#define __IR_RECV_H__

#include "stm32f4xx.h"

void IR_Recv_Init(void);
void IR_Recv(void);

#endif /* __IR_RECV_H__ */
