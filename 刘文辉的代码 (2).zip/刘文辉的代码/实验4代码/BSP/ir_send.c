#include "ir_send.h"
#include "delay.h"

/* 红外发射使用 TIM8_CH1, 对应 PC6, 产生38kHz载波 */
#define IR_SEND_TIM        TIM8
#define IR_SEND_GPIO       GPIOC
#define IR_SEND_PIN        GPIO_Pin_6
#define IR_SEND_PINSOURCE  GPIO_PinSource6
#define IR_SEND_AF         GPIO_AF_TIM8

/* NEC协议时序 (单位: us) */
#define NEC_LEAD_LOW       9000
#define NEC_LEAD_HIGH      4500
#define NEC_REPEAT_LOW     9000
#define NEC_REPEAT_HIGH    2250
#define NEC_BIT_LOW        560
#define NEC_BIT0_HIGH      560
#define NEC_BIT1_HIGH      1680

/* 38kHz载波: 占空比1/3, 周期约26.3us */
#define IR_CARRIER_PERIOD  26
#define IR_CARRIER_HIGH    9

void IR_Send_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
    TIM_OCInitTypeDef TIM_OCInitStruct;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);

    GPIO_PinAFConfig(IR_SEND_GPIO, IR_SEND_PINSOURCE, IR_SEND_AF);
    GPIO_InitStruct.GPIO_Pin   = IR_SEND_PIN;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(IR_SEND_GPIO, &GPIO_InitStruct);

    TIM_TimeBaseStruct.TIM_Period        = IR_CARRIER_PERIOD - 1;
    TIM_TimeBaseStruct.TIM_Prescaler     = 83;
    TIM_TimeBaseStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStruct.TIM_CounterMode   = TIM_CounterMode_Up;
    TIM_TimeBaseInit(IR_SEND_TIM, &TIM_TimeBaseStruct);

    TIM_OCInitStruct.TIM_OCMode      = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse       = IR_CARRIER_HIGH;
    TIM_OCInitStruct.TIM_OCPolarity  = TIM_OCPolarity_High;
    TIM_OC1Init(IR_SEND_TIM, &TIM_OCInitStruct);

    TIM_OC1PreloadConfig(IR_SEND_TIM, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(IR_SEND_TIM, ENABLE);

    TIM_Cmd(IR_SEND_TIM, DISABLE);
    TIM_CtrlPWMOutputs(IR_SEND_TIM, DISABLE);
}

static void IR_Carrier_ON(void)
{
    TIM_SetCounter(IR_SEND_TIM, 0);
    TIM_Cmd(IR_SEND_TIM, ENABLE);
    TIM_CtrlPWMOutputs(IR_SEND_TIM, ENABLE);
}

static void IR_Carrier_OFF(void)
{
    TIM_CtrlPWMOutputs(IR_SEND_TIM, DISABLE);
    TIM_Cmd(IR_SEND_TIM, DISABLE);
}

void IR_Send_NEC(uint8_t addr, uint8_t cmd)
{
    uint32_t data;
    uint8_t i;

    data = (uint32_t)addr
         | ((uint32_t)(~addr) << 8)
         | ((uint32_t)cmd << 16)
         | ((uint32_t)(~cmd) << 24);

    IR_Carrier_ON();
    delay_us(NEC_LEAD_LOW);
    IR_Carrier_OFF();
    delay_us(NEC_LEAD_HIGH);

    for (i = 0; i < 32; i++)
    {
        IR_Carrier_ON();
        delay_us(NEC_BIT_LOW);
        IR_Carrier_OFF();

        if (data & 0x01)
            delay_us(NEC_BIT1_HIGH);
        else
            delay_us(NEC_BIT0_HIGH);

        data >>= 1;
    }

    IR_Carrier_ON();
    delay_us(NEC_BIT_LOW);
    IR_Carrier_OFF();
}
