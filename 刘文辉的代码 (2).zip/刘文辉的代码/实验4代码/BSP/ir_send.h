#ifndef __IR_SEND_H__
#define __IR_SEND_H__

#include "stm32f4xx.h"

void IR_Send_Init(void);
void IR_Send_NEC(uint8_t addr, uint8_t cmd);

#endif /* __IR_SEND_H__ */
