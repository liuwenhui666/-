#include <stdio.h>
#include "stm32f4xx.h"
#include "ir_recv.h"
#include "ir_send.h"
#include "usart.h"
#include "delay.h"

void IR_Rece_Proc(uint16_t addr, uint8_t code)
{
    printf("IRRecv:addr:%d, code:%d\r\n", addr, code);

    /* 将收到的键码重新发送出去(红外转发) */
    IR_Send_NEC((uint8_t)addr, code);
    printf("IR Send OK: addr=%d, code=%d\r\n", addr, code);
}

int main(void)
{
    UART2_Init(115200);
    delay_init();
    IR_Recv_Init();
    IR_Send_Init();

    printf("IR Recv & Send Init OK\r\n");
    printf("System Ready! Press IR remote key...\r\n\r\n");

    while (1)
    {
        IR_Recv();
    }
}
