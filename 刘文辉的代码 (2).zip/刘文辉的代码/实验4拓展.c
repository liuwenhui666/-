#include "stm32f4xx.h"

/*==============================================================*/
/*                      变量定义区                               */
/*==============================================================*/
u8   OD_Flag = 0;        // 收到0x0D回车符的标志
u8   Rx_Frame_Flag = 0;  // 收到完整帧的标志
u8   Rx_Buf[64];         // 接收缓存
u16  Rx_Con = 0;         // 接收计数器
u16  Rx_Len = 0;         // 接收长度
u8   Error = 0;          // 错误指令的标志

/*==============================================================*/
/*                    结构体变量定义                              */
/*==============================================================*/
GPIO_InitTypeDef  GPIO_InitStructure;
USART_InitTypeDef USART_InitStructure;
NVIC_InitTypeDef  NVIC_InitStructure;

/*==============================================================*/
/*                      函数声明区                               */
/*==============================================================*/
void USART2_Send_Frame(u8* data, u16 len);
void delay_us(uint16_t nus);
void delay_ms(u16 nms);

/**
  * @brief  主函数
  *
  * 指令协议设计（带回车换行发送）：
  *   LED1ON   - 点亮LED1  (6字节)
  *   LED1OFF  - 熄灭LED1  (7字节)
  *   LED2ON   - 点亮LED2  (6字节)
  *   LED2OFF  - 熄灭LED2  (7字节)
  *   LED3ON   - 点亮LED3  (6字节)
  *   LED3OFF  - 熄灭LED3  (7字节)
  *   ALLON    - 全部点亮   (5字节)
  *   ALLOFF   - 全部熄灭   (6字节)
  *   BEEP     - 蜂鸣器响   (4字节)
  *   ST       - 查询LED状态 (2字节)
  */
int main(void)
{
    /*============================================================*/
    /*  第1步：配置三个LED（PB5=LED1, PB0=LED2, PB1=LED3）         */
    /*============================================================*/
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5 | GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_SetBits(GPIOB, GPIO_Pin_5 | GPIO_Pin_0 | GPIO_Pin_1);  // 初始熄灭
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /*============================================================*/
    /*  第2步：配置蜂鸣器（PA8）                                     */
    /*============================================================*/
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_SetBits(GPIOA, GPIO_Pin_8);  // 初始不响
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /*============================================================*/
    /*  第3步：使能GPIOA和USART2时钟                               */
    /*============================================================*/
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    /*============================================================*/
    /*  第4步：USART2 GPIO配置（PA2=TX, PA3=RX）                   */
    /*============================================================*/
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2 | GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);

    /*============================================================*/
    /*  第5步：USART2 端口配置                                      */
    /*============================================================*/
    USART_InitStructure.USART_BaudRate            = 115200;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                 = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);

    USART_Cmd(USART2, ENABLE);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    /*============================================================*/
    /*  第6步：配置NVIC中断                                          */
    /*============================================================*/
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);

    NVIC_InitStructure.NVIC_IRQChannel                    = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority  = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority         = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd                 = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /*============================================================*/
    /*  发送欢迎信息和使用说明                                       */
    /*============================================================*/
    USART2_Send_Frame("=== STM32 LED Control ===\r\n", 28);
    USART2_Send_Frame("LED1ON/LED1OFF\r\n", 17);
    USART2_Send_Frame("LED2ON/LED2OFF\r\n", 17);
    USART2_Send_Frame("LED3ON/LED3OFF\r\n", 17);
    USART2_Send_Frame("ALLON/ALLOFF\r\n", 15);
    USART2_Send_Frame("BEEP / ST\r\n", 13);
    USART2_Send_Frame("======================\r\n", 24);

    /*============================================================*/
    /*  主循环：解析串口指令并控制LED                                 */
    /*============================================================*/
    while(1)
    {
        if(Rx_Frame_Flag)
        {
            Rx_Frame_Flag = 0;
            Error = 0;

            /*======= 4字节指令：BEEP =======*/
            if(Rx_Len == 4)
            {
                if(('B' == Rx_Buf[0]) && ('E' == Rx_Buf[1]) &&
                   ('E' == Rx_Buf[2]) && ('P' == Rx_Buf[3]))
                {
                    GPIO_ResetBits(GPIOA, GPIO_Pin_8);  // 蜂鸣器响
                    delay_ms(80);
                    GPIO_SetBits(GPIOA, GPIO_Pin_8);    // 蜂鸣器停
                    USART2_Send_Frame("[OK] BEEP\r\n", 12);
                }
                else
                {
                    Error = 1;
                }
            }
            /*======= 2字节指令：ST =======*/
            else if(Rx_Len == 2)
            {
                if(('S' == Rx_Buf[0]) && ('T' == Rx_Buf[1]))
                {
                    USART2_Send_Frame("--- Status ---\r\n", 16);
                    if(GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_5))
                        USART2_Send_Frame("LED1: OFF\r\n", 11);
                    else
                        USART2_Send_Frame("LED1: ON\r\n", 10);
                    if(GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_0))
                        USART2_Send_Frame("LED2: OFF\r\n", 11);
                    else
                        USART2_Send_Frame("LED2: ON\r\n", 10);
                    if(GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_1))
                        USART2_Send_Frame("LED3: OFF\r\n", 11);
                    else
                        USART2_Send_Frame("LED3: ON\r\n", 10);
                    USART2_Send_Frame("--------------\r\n", 17);
                }
                else
                {
                    Error = 1;
                }
            }
            /*======= 5字节指令：ALLON =======*/
            else if(Rx_Len == 5)
            {
                if(('A' == Rx_Buf[0]) && ('L' == Rx_Buf[1]) &&
                   ('L' == Rx_Buf[2]) && ('O' == Rx_Buf[3]) &&
                   ('N' == Rx_Buf[4]))
                {
                    /* ALLON - 全部点亮 */
                    GPIO_ResetBits(GPIOB, GPIO_Pin_5 | GPIO_Pin_0 | GPIO_Pin_1);
                    USART2_Send_Frame("[OK] ALL ON\r\n", 14);
                }
                else
                {
                    Error = 1;
                }
            }
            /*======= 6字节指令：LEDxON / ALLOFF =======*/
            else if(Rx_Len == 6)
            {
                if(('A' == Rx_Buf[0]) && ('L' == Rx_Buf[1]) &&
                   ('L' == Rx_Buf[2]) && ('O' == Rx_Buf[3]) &&
                   ('F' == Rx_Buf[4]) && ('F' == Rx_Buf[5]))
                {
                    /* ALLOFF - 全部熄灭 */
                    GPIO_SetBits(GPIOB, GPIO_Pin_5 | GPIO_Pin_0 | GPIO_Pin_1);
                    USART2_Send_Frame("[OK] ALL OFF\r\n", 15);
                }
                else if(('L' == Rx_Buf[0]) && ('E' == Rx_Buf[1]) &&
                        ('D' == Rx_Buf[2]) && ('O' == Rx_Buf[4]) &&
                        ('N' == Rx_Buf[5]))
                {
                    /* LEDxON - 点亮某个LED */
                    if('1' == Rx_Buf[3])
                    {
                        GPIO_ResetBits(GPIOB, GPIO_Pin_5);
                        USART2_Send_Frame("[OK] LED1 ON\r\n", 15);
                    }
                    else if('2' == Rx_Buf[3])
                    {
                        GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                        USART2_Send_Frame("[OK] LED2 ON\r\n", 15);
                    }
                    else if('3' == Rx_Buf[3])
                    {
                        GPIO_ResetBits(GPIOB, GPIO_Pin_1);
                        USART2_Send_Frame("[OK] LED3 ON\r\n", 15);
                    }
                    else
                    {
                        Error = 1;
                    }
                }
                else
                {
                    Error = 1;
                }
            }
            /*======= 7字节指令：LEDxOFF =======*/
            else if(Rx_Len == 7)
            {
                if(('L' == Rx_Buf[0]) && ('E' == Rx_Buf[1]) &&
                   ('D' == Rx_Buf[2]) && ('O' == Rx_Buf[4]) &&
                   ('F' == Rx_Buf[5]) && ('F' == Rx_Buf[6]))
                {
                    /* LEDxOFF - 熄灭某个LED */
                    if('1' == Rx_Buf[3])
                    {
                        GPIO_SetBits(GPIOB, GPIO_Pin_5);
                        USART2_Send_Frame("[OK] LED1 OFF\r\n", 16);
                    }
                    else if('2' == Rx_Buf[3])
                    {
                        GPIO_SetBits(GPIOB, GPIO_Pin_0);
                        USART2_Send_Frame("[OK] LED2 OFF\r\n", 16);
                    }
                    else if('3' == Rx_Buf[3])
                    {
                        GPIO_SetBits(GPIOB, GPIO_Pin_1);
                        USART2_Send_Frame("[OK] LED3 OFF\r\n", 16);
                    }
                    else
                    {
                        Error = 1;
                    }
                }
                else
                {
                    Error = 1;
                }
            }
            else
            {
                Error = 1;
            }

            /*------- 发送报错信息 -------*/
            if(Error)
            {
                Error = 0;
                USART2_Send_Frame("[ERR] Unknown!\r\n", 19);
            }
        }
    }
}

/**
  * @brief  UART2 帧发送函数
  * @param  data: 要发送的数据
  * @param  len:  数据长度（字节数）
  */
void USART2_Send_Frame(u8* data, u16 len)
{
    u16 i;
    for(i = 0; i < len; i++)
    {
        while(USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);
        USART_SendData(USART2, data[i]);
    }
}

/**
  * @brief  串口2中断处理函数
  * @note   以\r\n（0x0D 0x0A）作为帧结束标志
  */
void USART2_IRQHandler(void)
{
    u8 res = 0;

    if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE))
    {
        res = USART_ReceiveData(USART2);

        if(OD_Flag)     // 已收到0x0D
        {
            if(res == 0x0A)   // 收到0x0A，帧结束
            {
                Rx_Frame_Flag = 1;
                Rx_Len = Rx_Con;
                Rx_Con = 0;
                OD_Flag = 0;
            }
        }
        else
        {
            if(res == 0x0D)
            {
                OD_Flag = 1;
            }
            else
            {
                Rx_Buf[Rx_Con] = res;
                Rx_Con++;
            }
        }
    }
}

/**
  * @brief  微秒延时函数
  */
void delay_us(uint16_t nus)
{
    uint16_t i;
    while(nus--)
    {
        i = 31;
        while(i--);
    }
}

/**
  * @brief  毫秒延时函数
  */
void delay_ms(u16 nms)
{
    uint16_t i;
    while(nms--)
    {
        i = 33800;
        while(i--);
    }
}
