/**
 * 实验5-1 时钟配置和定时器TIM3的一般定时实验
 * 
 * 功能说明：
 *   配置TIM3为一般定时功能，溢出时间为500毫秒，
 *   开启中断功能，在中断服务函数中点亮或熄灭LED1（PB5），
 *   实现一秒钟一次的LED闪烁功能。
 * 
 * 硬件平台：青软遨游100开发板（QST-AU100） STM32F407
 * 
 * 时钟计算：
 *   系统时钟 SYSCLK = 168MHz
 *   APB1时钟 = SYSCLK / 4 = 42MHz
 *   TIM3时钟 = APB1 x 2 = 84MHz
 *   预分频后时钟 = 84MHz / 8400 = 10000Hz (10KHz)
 *   计数周期 = (Period + 1) / 10000 = (4999 + 1) / 10000 = 0.5秒
 *   LED闪烁周期 = 0.5秒 x 2 = 1秒（亮0.5秒、灭0.5秒）
 */

#include "stm32f4xx.h"

/* 定义所需的初始化结构体 */
GPIO_InitTypeDef GPIO_InitStructure;            // GPIO初始化结构体
TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure; // 定时器初始化结构体
NVIC_InitTypeDef NVIC_InitStructure;            // NVIC初始化结构体

/**
 * @brief  主函数
 * @retval int
 */
int main(void)
{
    /* ========== 1. 配置和初始化LED1的GPIO（PB5） ========== */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); // 使能GPIOB时钟

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;      // 选择LED1 PB5
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;   // 输出模式
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; // 推挽输出模式
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; // 低速省电

    GPIO_SetBits(GPIOB, GPIO_Pin_5);                 // 预先熄灭LED1
    GPIO_Init(GPIOB, &GPIO_InitStructure);            // 初始化PB5

    /* ========== 2. 配置定时器TIM3 ========== */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); // 使能TIM3时钟

    /* 配置TIM3的分频值、预装值、计数方向 */
    TIM_TimeBaseInitStructure.TIM_Period    = 4999;             // 预装载值（ARR）
    TIM_TimeBaseInitStructure.TIM_Prescaler = 8400;             // 预分频系数（PSC）
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; // 向上计数模式
    TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;            // 时钟分割（一般定时无需配置）
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;        // 重复计数器（TIM3无此功能）

    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure); // 初始化定时器TIM3

    /* ========== 3. 配置定时器中断 ========== */
    TIM_ClearFlag(TIM3, TIM_FLAG_Update);            // 清除一次定时器更新标志
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);       // 开启定时器3更新（溢出）中断

    /* ========== 4. 配置NVIC中断向量 ========== */
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;                 // 定时器3中断向量
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;    // 抢占优先级1
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x03;           // 子优先级3
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                 // 使能中断通道
    NVIC_Init(&NVIC_InitStructure);                                 // 初始化NVIC

    /* ========== 5. 启动定时器3开始计数 ========== */
    TIM_Cmd(TIM3, ENABLE);

    /* ========== 6. 主循环 ========== */
    while(1)
    {
        // 主循环中没有内容，LED闪烁完全由中断服务函数控制
    }
}

/**
 * @brief  定时器3中断服务函数
 *         每500毫秒进入一次中断，通过静态变量i控制LED1的亮灭
 */
void TIM3_IRQHandler(void)
{
    static u8 i; // 静态变量i，每次退出函数后不会被清零

    if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET) // 判断是定时器3溢出中断
    {
        if (i)
        {
            i = 0;
            GPIO_ResetBits(GPIOB, GPIO_Pin_5); // 点亮LED1（PB5，低电平点亮）
        }
        else
        {
            i = 1;
            GPIO_SetBits(GPIOB, GPIO_Pin_5);  // 熄灭LED1（PB5，高电平熄灭）
        }
    }
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update); // 清除中断标志位
}

/**
 * 附录：时钟系统说明
 * 
 * STM32F407时钟信号产生路径：
 *   HSE(8MHz晶振) → PLL_M(÷8) → PLL_N(×336) → PLL_P(÷2) → PLLCLK(168MHz) → SYSCLK
 * 
 * 相关配置在 system_stm32f4xx.c 文件中：
 *   PLL_M  = 8   （晶振8MHz / 8 = 1MHz）
 *   PLL_N  = 336 （1MHz × 336 = 336MHz）
 *   PLL_P  = 2   （336MHz / 2 = 168MHz）
 * 
 * 修改示例：若将 PLL_N 改为 168，则 SYSCLK = 84MHz，
 *           LED闪烁频率会降低一半，变为每2秒闪一次。
 * 
 * TIM3时钟路径：
 *   SYSCLK(168MHz) → AHB分频(÷1) → APB1分频(÷4=42MHz) → TIM3倍频(×2=84MHz)
 *   84MHz / PSC(8400) = 10000Hz
 *   计数(Period+1) = 5000 个时钟周期 → 500ms溢出一次
 */
