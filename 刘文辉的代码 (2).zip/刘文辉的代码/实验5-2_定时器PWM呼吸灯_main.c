/**
 * 实验5-2 定时器TIM3 PWM呼吸灯功能实验
 * 
 * 功能说明：
 *   配置TIM3为PWM输出模式，输出GPIO引脚(PB5)驱动LED，
 *   通过脉宽调制（PWM）改变LED亮度。
 *   按键1（PA0）增加PWM值（增加亮度），
 *   按键2（PC13）减少PWM值（降低亮度）。
 * 
 * 硬件平台：青软遨游100开发板（QST-AU100） STM32F407
 * 
 * PWM计算：
 *   TIM3时钟 = 84MHz
 *   预分频后时钟 = 84MHz / 84 = 1MHz (1000KHz)
 *   PWM频率 = 1MHz / Period(500) = 2KHz
 *   占空比范围 = CCR2 / Period × 100%  （CCR2: 0~499）
 *   PWM值范围：0（熄灭）~ 499（最亮）
 */

#include "stm32f4xx.h"

/* 变量定义 */
u16 PWM_Value = 0; // PWM值的临时变量，范围0~499

/* 定义所需的初始化结构体变量 */
GPIO_InitTypeDef GPIO_InitStructure;
TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
TIM_OCInitTypeDef TIM_OCInitStructure;

/* 函数声明 */
void delay_us(uint16_t nus);
void delay_ms(u16 nms);

/**
 * @brief  主函数
 * @retval int
 */
int main(void)
{
    /* ========== 1. 配置按键KEY1和KEY2的GPIO为输入 ========== */
    /* 开启GPIOA和GPIOC的时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOC, ENABLE);

    /* 配置KEY1所在的GPIO（PA0） */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0;    // 引脚号PA0
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;   // GPIO设置为输入模式
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; // 速度设置为2MHz
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;   // 上拉电阻
    GPIO_Init(GPIOA, &GPIO_InitStructure);           // 初始化GPIOA

    /* 配置KEY2所在的GPIO（PC13） */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_13;    // 引脚号PC13
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;   // GPIO设置为输入模式
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; // 速度设置为2MHz
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;   // 上拉电阻
    GPIO_Init(GPIOC, &GPIO_InitStructure);           // 初始化GPIOC

    /* ========== 2. 配置TIM3和GPIOB时钟 ========== */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); // 使能TIM3时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); // 使能PORTB时钟

    /* ========== 3. 连接PB5为TIM3复用功能 ========== */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource5, GPIO_AF_TIM3); // 连接PB5为定时器3复用

    /* ========== 4. 配置PB5为复用推挽输出（TIM3的PWM输出Pin） ========== */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;         // PB5
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;        // IO复用功能
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;  // 速度100MHz
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;     // 推挽复用输出
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;        // 上拉
    GPIO_Init(GPIOB, &GPIO_InitStructure);               // 初始化PB5

    /* ========== 5. 配置TIM3的分频、方向、预装值和时钟分割因子 ========== */
    TIM_TimeBaseStructure.TIM_Prescaler     = 84;                // 定时器预分频（84MHz / 84 = 1MHz）
    TIM_TimeBaseStructure.TIM_CounterMode   = TIM_CounterMode_Up; // 向上计数模式
    TIM_TimeBaseStructure.TIM_Period         = 500 - 1;          // 预装载值（ARR = 499）
    TIM_TimeBaseStructure.TIM_ClockDivision  = TIM_CKD_DIV1;      // 时钟分割因子
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);               // 初始化TIM3

    /* ========== 6. 配置TIM3的PWM模式 ========== */
    TIM_OCInitStructure.TIM_OCMode      = TIM_OCMode_PWM1;        // 脉宽调制模式1
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;  // 使能比较输出
    TIM_OCInitStructure.TIM_OCPolarity  = TIM_OCPolarity_Low;      // 输出极性为低
    TIM_OC2Init(TIM3, &TIM_OCInitStructure);                       // 初始化TIM3通道2的PWM

    /* ========== 7. 使能预装载寄存器 ========== */
    TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable); // 使能TIM3在CCR2上的预装载寄存器
    TIM_ARRPreloadConfig(TIM3, ENABLE);                // 使能ARPE（自动重装载预装载）

    /* ========== 8. 使能TIM3开始计数 ========== */
    TIM_Cmd(TIM3, ENABLE); // 使能TIM3

    /* ========== 9. 初始PWM测试：间隔0.5秒依次输入四个PWM值 ========== */
    TIM_SetCompare2(TIM3, 499); // 写入PWM值(0~499)，最亮
    delay_ms(500);
    TIM_SetCompare2(TIM3, 300); // 写入PWM值(0~499)，较亮
    delay_ms(500);
    TIM_SetCompare2(TIM3, 100); // 写入PWM值(0~499)，较暗
    delay_ms(500);
    TIM_SetCompare2(TIM3, 0);   // 写入PWM值(0~499)，熄灭

    /* ========== 10. 主循环：检测按键增减PWM值 ========== */
    while(1)
    {
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)) // 按键1（PA0）被按下
        {
            if (PWM_Value < 500) // 小于500就加一
            {
                PWM_Value++;
                TIM_SetCompare2(TIM3, PWM_Value); // 重新写入PWM值
            }
        }
        else if (0 == GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13)) // 按键2（PC13）被按下
        {
            if (PWM_Value > 0) // 大于0就减一
            {
                PWM_Value--;
                TIM_SetCompare2(TIM3, PWM_Value); // 重新写入PWM值
            }
        }
        delay_ms(20); // 检测间隔20毫秒，每秒50次
    }
}

/**
 * @brief  微秒级延时函数
 * @param  nus 延时的微秒数
 */
void delay_us(uint16_t nus)
{
    uint16_t i;
    while(nus--)
    {
        i = 31;
        while(i--);
    }
}

/**
 * @brief  毫秒级延时函数
 * @param  nms 延时的毫秒数
 */
void delay_ms(u16 nms)
{
    uint16_t i;
    while(nms--)
    {
        i = 33800;
        while(i--);
    }
}

/**
 * 附录：PWM原理解析
 * 
 * PWM（Pulse Width Modulation）脉冲宽度调制：
 *   不改变供给电器的电压，而是快速通断电压，
 *   通过调节"接通"和"切断"的时间比例（占空比）来控制LED亮度。
 * 
 * 本实验参数：
 *   PWM频率 = 84MHz / (PSC+1) / (ARR+1) = 84MHz / 84 / 500 = 2KHz
 *   占空比 = CCR2 / (ARR+1) × 100% = CCR2 / 500 × 100%
 *   CCR2 = 0   → 占空比 0%   → LED熄灭
 *   CCR2 = 100 → 占空比 20%  → LED较暗
 *   CCR2 = 300 → 占空比 60%  → LED较亮
 *   CCR2 = 499 → 占空比 ~100%→ LED最亮
 * 
 * 按键调节：
 *   KEY1（PA0）按下 → PWM_Value++（增加亮度）
 *   KEY2（PC13）按下 → PWM_Value--（降低亮度）
 *   检测间隔20ms，从0到499约需10秒
 */
