/**
 * 实验6-1：ADC电位器控制LED1闪烁频率
 * 功能：旋转电位器（PC1）改变ADC值，ADC值映射为延时时间（100ms~2000ms），
 *       从而控制LED1（PB5）的闪烁频率。
 * 硬件：青软 遨游100开发板（QST-AU100）
 */

#include "stm32f4xx.h"

/*------------------ 变量定义 ------------------*/
u16 Adc = 0;        // ADC值 (0-4095)
u16 DelayTime = 0;  // 闪烁延时时间 (单位: ms, 100~2000)

/*------------------ 结构体定义 ------------------*/
GPIO_InitTypeDef   GPIO_InitStructure;
ADC_CommonInitTypeDef ADC_CommonInitStructure;
ADC_InitTypeDef    ADC_InitStructure;

/*------------------ 函数声明 ------------------*/
void delay_us(uint16_t nus);
void delay_ms(u16 nms);
void Adc_Init(void);
void Led_Init(void);
uint16_t Get_Adc(uint8_t ch);
uint16_t Get_Adc_Average(uint8_t ch, uint8_t times);

/**
 * @brief  主函数
 */
int main(void)
{
    /* 初始化LED1 (PB5) */
    Led_Init();

    /* 初始化ADC1 (PC1, Channel_11) */
    Adc_Init();

    while(1)
    {
        /* 获取ADC通道11的10次平均值 */
        Adc = Get_Adc_Average(ADC_Channel_11, 10);

        /*
         * ADC值范围: 0 ~ 4095
         * 映射到延时时间: 100ms ~ 2000ms
         * 计算公式: DelayTime = 100 + (Adc / 4095) * 1900
         *          简化:   DelayTime = 100 + Adc * 1900 / 4095
         *          近似:   DelayTime = 100 + Adc / 2   (Adc/4095 * 1900 ≈ Adc*0.464)
         *
         * 为了更精确，使用: DelayTime = 100 + (u32)Adc * 1900 / 4095;
         */
        DelayTime = 100 + (u32)Adc * 1900 / 4095;

        /* LED1点亮 */
        GPIO_ResetBits(GPIOB, GPIO_Pin_5);  // PB5输出低电平，LED亮
        delay_ms(DelayTime);

        /* LED1熄灭 */
        GPIO_SetBits(GPIOB, GPIO_Pin_5);    // PB5输出高电平，LED灭
        delay_ms(DelayTime);
    }
}

/**
 * @brief  LED1初始化函数
 * @note   LED1连接在PB5引脚，配置为推挽输出
 */
void Led_Init(void)
{
    /* 使能GPIOB时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    /* 配置PB5为通用推挽输出模式 */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* 默认熄灭LED1 */
    GPIO_SetBits(GPIOB, GPIO_Pin_5);
}

/**
 * @brief  ADC1初始化函数
 * @note   配置ADC1通道11 (PC1)，12bit独立模式，非连续转换
 */
void Adc_Init(void)
{
    /* 使能GPIOC和ADC1时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    /* 配置PC1为模拟输入模式，无上下拉电阻 */
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    /* ADC1复位 */
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_ADC1, DISABLE);

    /* 配置ADC_Common */
    ADC_CommonInitStructure.ADC_Mode                 = ADC_Mode_Independent;
    ADC_CommonInitStructure.ADC_TwoSamplingDelay     = ADC_TwoSamplingDelay_5Cycles;
    ADC_CommonInitStructure.ADC_DMAAccessMode         = ADC_DMAAccessMode_Disabled;
    ADC_CommonInitStructure.ADC_Prescaler             = ADC_Prescaler_Div6;
    ADC_CommonInit(&ADC_CommonInitStructure);

    /* 配置ADC1参数 */
    ADC_InitStructure.ADC_Resolution            = ADC_Resolution_12b;
    ADC_InitStructure.ADC_ScanConvMode          = DISABLE;   // 非扫描模式
    ADC_InitStructure.ADC_ContinuousConvMode    = DISABLE;   // 关闭连续转换
    ADC_InitStructure.ADC_ExternalTrigConvEdge  = ADC_ExternalTrigConvEdge_None;
    ADC_InitStructure.ADC_DataAlign             = ADC_DataAlign_Right;   // 右对齐
    ADC_InitStructure.ADC_NbrOfConversion        = 1;                     // 转换序列1
    ADC_Init(ADC1, &ADC_InitStructure);

    /* 开启ADC1 */
    ADC_Cmd(ADC1, ENABLE);
}

/**
 * @brief  ADC转换一次
 * @param  ch: ADC通道号
 * @return 转换后的12位ADC值
 */
uint16_t Get_Adc(u8 ch)
{
    /* 配置ADC通道和采样时间 */
    ADC_RegularChannelConfig(ADC1, ch, 1, ADC_SampleTime_480Cycles);

    /* 开启ADC转换 */
    ADC_SoftwareStartConv(ADC1);

    /* 等待ADC转换完成 */
    while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC));

    /* 返回ADC转换数据 */
    return ADC_GetConversionValue(ADC1);
}

/**
 * @brief  ADC转换N次取平均值
 * @param  ch:    ADC通道号
 * @param  times: 转换次数（建议不少于8次）
 * @return 多次转换的平均值
 */
uint16_t Get_Adc_Average(uint8_t ch, uint8_t times)
{
    uint32_t temp_val = 0;
    uint8_t  i;

    for(i = 0; i < times; i++)
    {
        temp_val += Get_Adc(ch);
        delay_ms(5);
    }

    return temp_val / times;
}

/**
 * @brief  微秒级延时函数
 * @param  nus: 延时的微秒数
 */
void delay_us(uint16_t nus)
{
    uint16_t i;
    while(nus--)
    {
        i = 31;
        while(i--);
    }
}

/**
 * @brief  毫秒级延时函数
 * @param  nms: 延时的毫秒数
 */
void delay_ms(u16 nms)
{
    uint16_t i;
    while(nms--)
    {
        i = 33800;
        while(i--);
    }
}
