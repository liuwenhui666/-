/**
 * 实验6-2：DAC递减电压输出
 * 功能：初始化STM32F407的DAC通道1（PA4），从3.3V（4095）开始递减输出电压，
 *       每次减少约0.2V（减248），到0V后重新从3.3V开始，使用万用表测量PA4观察。
 * 硬件：青软 遨游100开发板（QST-AU100）
 */

#include "stm32f4xx.h"

/*------------------ 变量定义 ------------------*/
u16 DacValue = 0xFFF;  // DAC输出值，初始设为最大值4095（对应3.3V）

/*------------------ 结构体定义 ------------------*/
GPIO_InitTypeDef  GPIO_InitStructure;
DAC_InitTypeDef   DAC_InitType;

/*------------------ 函数声明 ------------------*/
void delay_us(uint16_t nus);
void delay_ms(u16 nms);
void Dac_Init(void);

/**
 * @brief  主函数
 */
int main(void)
{
    /* 初始化DAC通道1 (PA4) */
    Dac_Init();

    while(1)
    {
        /* 设置DAC通道1的输出值（12位右对齐） */
        DAC_SetChannel1Data(DAC_Align_12b_R, DacValue);

        /*
         * 递减：每次减少248，输出电压大约降低0.2V
         * 248 / 4096 * 3.3V ≈ 0.2V
         *
         * 注意：使用带符号检查的递减方式，防止数值溢出
         */
        if(DacValue >= 248)
        {
            DacValue -= 248;  // 正常递减
        }
        else
        {
            DacValue = 0xFFF;  // 不足248时，重新回到最大值4095
        }

        /* 每次延时1秒 */
        delay_ms(1000);
    }
}

/**
 * @brief  DAC通道1初始化函数
 * @note   配置PA4为模拟模式，初始化DAC通道1为12位右对齐
 */
void Dac_Init(void)
{
    /* 使能GPIOA和DAC时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

    /* 配置PA4为模拟模式（DAC输出端） */
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* 配置DAC通道1参数 */
    DAC_InitType.DAC_Trigger                              = DAC_Trigger_None;              // 不使用触发功能
    DAC_InitType.DAC_WaveGeneration                       = DAC_WaveGeneration_None;        // 不使用波形发生器
    DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude         = DAC_LFSRUnmask_Bit0;            // 屏蔽幅值
    DAC_InitType.DAC_OutputBuffer                         = DAC_OutputBuffer_Disable;       // 关闭DAC输出缓存
    DAC_Init(DAC_Channel_1, &DAC_InitType);              // 初始化DAC通道1

    /* 使能DAC通道1 */
    DAC_Cmd(DAC_Channel_1, ENABLE);

    /* 设置初始输出值为最大值4095（3.3V），12位右对齐 */
    DAC_SetChannel1Data(DAC_Align_12b_R, 0xFFF);
}

/**
 * @brief  微秒级延时函数
 * @param  nus: 延时的微秒数
 */
void delay_us(uint16_t nus)
{
    uint16_t i;
    while(nus--)
    {
        i = 31;
        while(i--);
    }
}

/**
 * @brief  毫秒级延时函数
 * @param  nms: 延时的毫秒数
 */
void delay_ms(u16 nms)
{
    uint16_t i;
    while(nms--)
    {
        i = 33800;
        while(i--);
    }
}
