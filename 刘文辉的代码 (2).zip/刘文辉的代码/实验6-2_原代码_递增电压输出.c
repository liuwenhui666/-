/**
 * 实验6-2 原代码：DAC递增电压输出
 * 功能：初始化STM32F407的DAC通道1（PA4），从0V开始递增输出电压，
 *       每次增加约0.2V（加248），到3.3V后重新归零循环。
 * 硬件：青软 遨游100开发板（QST-AU100）
 */

#include "stm32f4xx.h"

/*------------------ 变量定义 ------------------*/
u16 DacValue = 0;  // DAC的输出值，初始为0（对应0V）

/*------------------ 结构体定义 ------------------*/
GPIO_InitTypeDef  GPIO_InitStructure;
DAC_InitTypeDef   DAC_InitType;

/*------------------ 函数声明 ------------------*/
void delay_us(uint16_t nus);
void delay_ms(u16 nms);

/**
 * @brief  主函数
 */
int main(void)
{
    /* 使能GPIOA和DAC时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

    /* 配置PA4为DAC的输出端 */
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;   // 模拟模式（输出）
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* 配置DAC的输出参数 */
    DAC_InitType.DAC_Trigger                      = DAC_Trigger_None;          // 不使用触发功能
    DAC_InitType.DAC_WaveGeneration               = DAC_WaveGeneration_None;   // 不用波形发生器
    DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude = DAC_LFSRUnmask_Bit0;       // 屏蔽幅值
    DAC_InitType.DAC_OutputBuffer                 = DAC_OutputBuffer_Disable;   // 关闭DAC1输出缓存
    DAC_Init(DAC_Channel_1, &DAC_InitType);                                   // 初始化DAC通道1

    DAC_Cmd(DAC_Channel_1, ENABLE);                      // 使能DAC通道1
    DAC_SetChannel1Data(DAC_Align_12b_R, 0);             // 12位右对齐数据格式，设置DAC值(0)

    /* 主循环：递增输出 */
    while(1)
    {
        DAC_SetChannel1Data(DAC_Align_12b_R, DacValue);  // 从0V电压开始输出（PA4）

        DacValue += 248;        // 每次增加248，输出电压大约增加0.2v

        if(0xFFF < DacValue)    // 超过了12位的最大值4095(0xFFF)
        {
            DacValue = 0;       // 清零重新开始
        }

        delay_ms(1000);         // 每次延时1秒一直循环
    }
}

/**
 * @brief  微秒级延时函数
 */
void delay_us(uint16_t nus)
{
    uint16_t i;
    while(nus--)
    {
        i = 31;
        while(i--);
    }
}

/**
 * @brief  毫秒级延时函数
 */
void delay_ms(u16 nms)
{
    uint16_t i;
    while(nms--)
    {
        i = 33800;
        while(i--);
    }
}
