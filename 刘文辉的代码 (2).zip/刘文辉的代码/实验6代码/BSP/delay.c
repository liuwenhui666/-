#include "delay.h"

static uint32_t fac_us = 0;

/**
  * @brief  延时函数初始化
  * @param  无
  * @retval 无
  */
void Delay_Init(void)
{
    // 配置SysTick定时器
    // SystemCoreClock / 1000000 得到每微秒的计数值
    fac_us = SystemCoreClock / 1000000;
}

/**
  * @brief  微秒级延时
  * @param  us：延时的微秒数
  * @retval 无
  */
void delay_us(uint32_t us)
{
    uint32_t temp;
    SysTick->LOAD = us * fac_us;        // 时间加载
    SysTick->VAL = 0x00;                // 清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;  // 开始倒数

    do
    {
        temp = SysTick->CTRL;
    }
    while((temp & 0x01) && !(temp & (1 << 16)));  // 等待时间到达

    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;  // 关闭计数器
    SysTick->VAL = 0x00;                        // 清空计数器
}

/**
  * @brief  毫秒级延时
  * @param  ms：延时的毫秒数
  * @retval 无
  */
void delay_ms(uint32_t ms)
{
    while(ms--)
    {
        delay_us(1000);
    }
}
