/**
 * @file    can.h
 * @brief   CAN总线对外接口头文件
 * @note    AU100开发板 - STM32F407
 *          CAN1: PA11(CAN_RX) / PA12(CAN_TX)
 */

#ifndef __CAN_H__
#define __CAN_H__
#include "stm32f4xx.h"

void CAN1_Init(void);
void CAN1_SendMsg(uint32_t uID, uint8_t *pData, uint32_t uLen);

#endif
