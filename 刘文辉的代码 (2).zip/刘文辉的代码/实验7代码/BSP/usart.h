/**
 * @file    usart.h
 * @brief   调试串口UART2对外接口头文件
 * @note    AU100开发板 - STM32F407
 */

#ifndef __USART_H__
#define __USART_H__
#include "stm32f4xx.h"

void UART2_Init(u32 bound);

#endif
