/**
 * @file    main.c
 * @brief   CAN总线LoopBack自发自收测试主程序
 * @note    AU100开发板 - STM32F407
 *          功能: 每5秒通过CAN1发送一帧数据，LoopBack模式下自动接收并打印
 */

#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "can.h"

/**
  * @brief  主函数
  * @param  无
  * @retval 无
  */
int main(void)
{
    // 测试数据: 8字节数据帧
    uint8_t pTxData[8] = {0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11};

    // 初始化延时函数
    delay_init();
    
    // 初始化调试串口UART2，波特率115200
    UART2_Init(115200);
    
    // 初始化CAN1，LoopBack模式，500Kbps
    CAN1_Init();

    printf("\r\n=== CAN LoopBack Test Start ===\r\n");

    while (1) {
        // 发送CAN数据帧，ID为0x1234
        CAN1_SendMsg(0x1234, pTxData, 8);
        
        // 延时5秒
        delay_ms(5000);
    }
}
