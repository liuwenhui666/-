/**
 * @file    delay.c
 * @brief   延时函数实现源码
 * @note    AU100开发板 - STM32F407
 *          基于SysTick定时器实现微秒/毫秒级延时
 */

#include "delay.h"

static u8  fac_us = 0; // us延时倍乘数
static u16 fac_ms = 0; // ms延时倍乘数

/**
 * @brief  延时初始化
 * @note   基于系统时钟配置SysTick
 */
void delay_init(void)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); // 选择外部时钟 HCLK/8
    fac_us = SystemCoreClock / 8000000;  // 8分频后为9MHz
    fac_ms = (u16)fac_us * 1000;        // 每毫秒需要的时钟数
}

/**
 * @brief  微秒级延时
 * @param  nus  延时微秒数
 */
void delay_us(u32 nus)
{
    u32 temp;
    SysTick->LOAD = nus * fac_us;         // 时间加载
    SysTick->VAL  = 0x00;                 // 清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk; // 开始倒数
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16))); // 等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;       // 关闭计数器
    SysTick->VAL = 0X00;                              // 清空计数器
}

/**
 * @brief  毫秒级延时
 * @param  nms  延时毫秒数
 */
void delay_ms(u16 nms)
{
    u32 temp;
    SysTick->LOAD = (u32)nms * fac_ms;    // 时间加载(SysTick为一个24bit递减计数器)
    SysTick->VAL  = 0x00;                  // 清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk; // 开始倒数
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16))); // 等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;       // 关闭计数器
    SysTick->VAL = 0X00;                              // 清空计数器
}
