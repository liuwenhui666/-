/**
 * @file    delay.h
 * @brief   延时函数头文件
 * @note    AU100开发板 - STM32F407
 */

#ifndef __DELAY_H__
#define __DELAY_H__
#include "stm32f4xx.h"

void delay_init(void);
void delay_ms(u16 nms);
void delay_us(u32 nus);

#endif
