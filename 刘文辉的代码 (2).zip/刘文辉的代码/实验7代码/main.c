/**
 * @file    main.c
 * @brief   STM32F407 DMA 串口发送实验（USART2 + DMA1_Stream6）
 * @note    青软 遨游100开发板（QST-AU100）
 *          USART2 TX -> PA2, USART2 RX -> PA3
 *          DMA1_Stream6, Channel4
 */

#include "stm32f4xx.h"
#include "delay.h"

/* 定义一帧数据，准备发送，\r\n 代表回车换行，共两个字节 */
uint8_t SendBuf[] = "Hello Everyone!\r\n"; /* 全长17个字节 */

/**
 * @brief  串口2（USART2）初始化
 * @param  baudrate: 波特率
 */
void USART2_Init(uint32_t baudrate)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;

    /* 使能 GPIOA 和 USART2 时钟 */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);   /* GPIOA 在 AHB1 高速总线上 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);  /* USART2 在 APB1 硬件总线上 */

    /* USART2 GPIO 配置 */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2 | GPIO_Pin_3; /* USART2 的 IO */
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF;            /* 复用模式 */
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;        /* 速度 50MHz */
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;            /* 推挽复用输出 */
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;            /* 上拉电阻 */
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* USART2 对应引脚复用映射 */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2); /* 映射 PA2 到 USART2_TX */
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2); /* 映射 PA3 到 USART2_RX */

    /* USART2 端口配置 */
    USART_InitStructure.USART_BaudRate            = baudrate;                       /* 波特率设置 */
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;           /* 字长 8bit */
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;              /* 1停止位 */
    USART_InitStructure.USART_Parity             = USART_Parity_No;               /* 无校验 */
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; /* 无硬件数据流控制 */
    USART_InitStructure.USART_Mode               = USART_Mode_Rx | USART_Mode_Tx;  /* 收发模式 */
    USART_Init(USART2, &USART_InitStructure);       /* 初始化 USART2 */

    USART_Cmd(USART2, ENABLE);                     /* 使能串口2 */
}

/**
 * @brief  DMA 串口发送初始化（USART2 TX -> DMA1_Stream6 Channel4）
 * @param  buf:   待发送数据缓冲区首地址
 * @param  len:   待发送数据长度（字节）
 */
void USART2_DMA_Init(uint8_t *buf, uint16_t len)
{
    DMA_InitTypeDef DMA_InitStruct;

    /* 1. 使能串口2的DMA发送功能 */
    USART_DMACmd(USART2, USART_DMAReq_Tx, ENABLE);

    /* 2. 开启 DMA1 时钟（USART2 TX 对应数据流在 DMA1 上） */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);

    /* 3. 先关闭 DMA 流，防止在配置过程中意外触发传输 */
    DMA_Cmd(DMA1_Stream6, DISABLE);

    /* 4. 等待 DMA 流确实关闭 */
    while (DMA_GetCmdStatus(DMA1_Stream6) != DISABLE) {}

    /* 5. 配置 DMA 通道、外设地址、存储器地址、数据方向、数量和递增要求 */
    DMA_InitStruct.DMA_Channel            = DMA_Channel_4;                      /* 通道选择 */
    DMA_InitStruct.DMA_PeripheralBaseAddr  = (uint32_t)&USART2->DR;              /* DMA 外设地址：串口2 数据寄存器 */
    DMA_InitStruct.DMA_Memory0BaseAddr     = (uint32_t)buf;                      /* DMA 存储器地址：要发送的数组 */
    DMA_InitStruct.DMA_DIR                = DMA_DIR_MemoryToPeripheral;         /* 存储器 --> 外设模式 */
    DMA_InitStruct.DMA_BufferSize          = len;                                /* 数据传输量 */
    DMA_InitStruct.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;          /* 外设地址不递增 */
    DMA_InitStruct.DMA_MemoryInc          = DMA_MemoryInc_Enable;               /* 存储器地址递增 */

    /* 6. 配置 DMA 其他参数 */
    DMA_InitStruct.DMA_PeripheralDataSize  = DMA_PeripheralDataSize_Byte;        /* 外设数据长度: 8位 */
    DMA_InitStruct.DMA_MemoryDataSize     = DMA_MemoryDataSize_Byte;           /* 存储器数据长度: 8位 */
    DMA_InitStruct.DMA_Mode               = DMA_Mode_Normal;                   /* 普通模式 */
    DMA_InitStruct.DMA_Priority            = DMA_Priority_Medium;               /* 中等优先级 */
    DMA_InitStruct.DMA_FIFOMode           = DMA_FIFOMode_Disable;              /* 不使用 FIFO */
    DMA_InitStruct.DMA_FIFOThreshold       = DMA_FIFOThreshold_Full;
    DMA_InitStruct.DMA_MemoryBurst         = DMA_MemoryBurst_Single;            /* 存储器突发单次传输 */
    DMA_InitStruct.DMA_PeripheralBurst     = DMA_PeripheralBurst_Single;        /* 外设突发单次传输 */

    /* 7. 初始化 DMA1 Stream6 */
    DMA_Init(DMA1_Stream6, &DMA_InitStruct);

    /* 8. 清除 DMA 传输完成标志（可选，防止残留标志干扰） */
    DMA_ClearFlag(DMA1_Stream6,
                  DMA_FLAG_TCIF6 | DMA_FLAG_HTIF6 |
                  DMA_FLAG_TEIF6 | DMA_FLAG_DMEIF6 | DMA_FLAG_FEIF6);

    /* 9. 启动 DMA 发送 */
    DMA_Cmd(DMA1_Stream6, ENABLE);
}

/**
 * @brief  主函数
 */
int main(void)
{
    /* 串口2 初始化，波特率 115200 */
    USART2_Init(115200);

    /* DMA 串口发送初始化，将 SendBuf 通过 DMA 发送 */
    USART2_DMA_Init(SendBuf, sizeof(SendBuf) - 1); /* sizeof 包含 '\0'，实际发送去掉末尾 '\0' */

    /*
     * 主循环为空 —— DMA 会自动完成数据传输
     * 电脑端串口调试工具应能收到 "Hello Everyone!\r\n"
     */
    while (1)
    {
    }
}
