#include "delay.h"

static u8  g_fac_us = 0;      //us延时倍乘数
static u16 g_fac_ms = 0;      //ms延时倍乘数

/**
  * @brief  延时初始化
  * @param  SYSCLK ：系统时钟频率（单位MHz）
  * @retval 无
  */
void delay_init(u8 SYSCLK)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);  //选择外部时钟 HCLK/8
    g_fac_us = SYSCLK / 8;                                 //1us所需的计数值
    g_fac_ms = (u16)g_fac_us * 1000;                       //1ms所需的计数值
}

/**
  * @brief  微秒级延时
  * @param  nus ：要延时的微秒数
  * @retval 无
  */
void delay_us(u32 nus)
{
    u32 temp;
    SysTick->LOAD = nus * g_fac_us;      //时间加载
    SysTick->VAL = 0x00;                 //清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;  //开始倒数
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));  //等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;  //关闭计数器
    SysTick->VAL = 0X00;              //清空计数器
}

/**
  * @brief  毫秒级延时
  * @param  nms ：要延时的毫秒数
  * @retval 无
  */
void delay_ms(u16 nms)
{
    u32 temp;
    SysTick->LOAD = (u32)nms * g_fac_ms;   //时间加载（SysTick->LOAD为24bit）
    SysTick->VAL = 0x00;                   //清空计数器
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;  //开始倒数
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));  //等待时间到达
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;  //关闭计数器
    SysTick->VAL = 0X00;              //清空计数器
}
