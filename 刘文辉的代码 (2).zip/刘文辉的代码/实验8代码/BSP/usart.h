#ifndef __USART_H__
#define __USART_H__

#include "stm32f4xx.h"

void UART2_Init(u32 bound);
void UART_SendByte(USART_TypeDef *pUSARTx, uint8_t ch);
void UART_SendString(USART_TypeDef *pUSARTx, char *str);
void UART_SendHalfWord(USART_TypeDef *pUSARTx, uint16_t ch);

#endif /* __USART_H__ */
