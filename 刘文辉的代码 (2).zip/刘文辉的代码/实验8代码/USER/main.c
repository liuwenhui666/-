#include <stdio.h>
#include "stm32f4xx.h"
#include "usart.h"
#include "lcd_ili9341.h"
#include "delay.h"

/**
  * @brief  主函数
  * @param  无
  * @retval 无
  */
int main(void)
{
    /* 系统初始化 */
    SystemInit();                       //系统时钟初始化
    delay_init(168);                    //延时初始化（168MHz）
    
    /* 调试串口初始化 */
    UART2_Init(115200);                 //调试串口，方便打印
    printf("LCD TEST\r\n"); 
    printf("ILI9341 LCD Driver Test\r\n");
    printf("Platform: STM32F407 + AU100\r\n\r\n");
    
    /* LCD初始化 */
    LCD_Init();
    printf("LCD Init Complete!\r\n");

    /* 设置字体和颜色 */
    LCD_SetFontEN(&ASCII_8x16);         //设置英文字体
    LCD_SetColors(RED, BLACK);          //设置前景色红色，背景色黑色

    /* 清屏 */
    LCD_Clear(0, 0, LCD_GetLenX(), LCD_GetLenY());    /* 清屏，显示全黑 */
    printf("LCD Clear Complete!\r\n");

    /* 显示字符串 */
    LCD_DispStringEN(0, LINE_EN(0), 0, "3.2 inch LCD:");
    LCD_DispStringEN(0, LINE_EN(1), 0, "Image resolution:240x320 px");
    
    /* 显示更多信息 */
    LCD_SetColors(GREEN, BLACK);
    LCD_DispStringEN(0, LINE_EN(3), 0, "Driver IC: ILI9341");
    LCD_DispStringEN(0, LINE_EN(4), 0, "Interface: FSMC 8080 16bit");
    
    LCD_SetColors(YELLOW, BLACK);
    LCD_DispStringEN(0, LINE_EN(6), 0, "STM32F407 + AU100 Board");
    LCD_DispStringEN(0, LINE_EN(7), 0, "LCD Test Program v1.0");
    
    LCD_SetColors(CYAN, BLACK);
    LCD_DispStringEN(0, LINE_EN(9), 0, "Font: ASCII 8x16");
    LCD_DispStringEN(0, LINE_EN(10), 0, "Color: RGB565 Format");
    
    /* 画一些图形元素 */
    LCD_SetTextColor(BLUE);
    LCD_DrawLine(0, 190, 239, 190);     //底部画线
    LCD_DrawLine(0, 191, 239, 191);     //加粗
    
    LCD_SetTextColor(WHITE);
    LCD_DispStringEN(0, LINE_EN(12), 0, "Test: ABCDEFGHIJKLMNOP");
    LCD_DispStringEN(0, LINE_EN(13), 0, "Test: 0123456789 !@#$%");
    
    printf("LCD Display Test Complete!\r\n");
    printf("All tests passed successfully.\r\n");
    
    while (1) {
        //主循环空转，所有显示工作已完成
    }
}
