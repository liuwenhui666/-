#include "oled.h"
#include "oledfont.h"
#include "delay.h"

/*===========================================
  本驱动基于 SSD1306 IIC 接口，分辨率 128×32
  引脚定义：SCL -> PB6，SDA -> PB7
  如实际硬件接线不同，请修改 oled.h 中的宏
===========================================*/

void IIC_Start(void)
{
    OLED_SCLK_Set();
    OLED_SDIN_Set();
    OLED_SDIN_Clr();
    OLED_SCLK_Clr();
}

void IIC_Stop(void)
{
    OLED_SCLK_Set();
    OLED_SDIN_Clr();
    OLED_SDIN_Set();
}

void IIC_WaitAck(void)
{
    OLED_SCLK_Set();
    OLED_SCLK_Clr();
}

void Write_IIC_Byte(uint8_t IIC_Byte)
{
    uint8_t i;
    for(i=0;i<8;i++)
    {
        OLED_SCLK_Clr();
        if(IIC_Byte & 0x80)
            OLED_SDIN_Set();
        else
            OLED_SDIN_Clr();
        IIC_Byte <<= 1;
        OLED_SCLK_Set();
        OLED_SCLK_Clr();
    }
    OLED_SCLK_Set();
    OLED_SCLK_Clr();
}

void OLED_WriteCmd(uint8_t cmd)
{
    IIC_Start();
    Write_IIC_Byte(0x78);
    IIC_WaitAck();
    Write_IIC_Byte(0x00);
    IIC_WaitAck();
    Write_IIC_Byte(cmd);
    IIC_WaitAck();
    IIC_Stop();
}

void OLED_WriteDat(uint8_t dat)
{
    IIC_Start();
    Write_IIC_Byte(0x78);
    IIC_WaitAck();
    Write_IIC_Byte(0x40);
    IIC_WaitAck();
    Write_IIC_Byte(dat);
    IIC_WaitAck();
    IIC_Stop();
}

void OLED_SetPos(uint8_t x, uint8_t y)
{
    OLED_WriteCmd(0xB0+y);
    OLED_WriteCmd(((x&0xF0)>>4)|0x10);
    OLED_WriteCmd(x&0x0F);
}

void OLED_Clear(void)
{
    uint8_t i,n;
    for(i=0;i<4;i++)
    {
        OLED_WriteCmd(0xB0+i);
        OLED_WriteCmd(0x00);
        OLED_WriteCmd(0x10);
        for(n=0;n<128;n++)
            OLED_WriteDat(0);
    }
}

void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t Char_Size)
{
    uint8_t c=chr-' ';
    uint8_t i;
    if(x > Max_Column-1)
    {
        x = 0;
        y += 2;
    }
    if(Char_Size == 16)
    {
        OLED_SetPos(x,y);
        for(i=0;i<8;i++)
            OLED_WriteDat(F8X16[c*16+i]);
        OLED_SetPos(x,y+1);
        for(i=0;i<8;i++)
            OLED_WriteDat(F8X16[c*16+i+8]);
    }
    else
    {
        OLED_SetPos(x,y);
        for(i=0;i<6;i++)
            OLED_WriteDat(F6x8[c][i]);
    }
}

void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *chr,uint8_t Char_Size)
{
    uint8_t j=0;
    while(chr[j] != '\0')
    {
        OLED_ShowChar(x,y,chr[j],Char_Size);
        if(Char_Size == 16)
            x += 8;
        else
            x += 6;
        if(x > 120)
        {
            x = 0;
            y += 2;
        }
        j++;
    }
}

void OLED_ShowCHinese(uint8_t x,uint8_t y,uint8_t no)
{
    uint8_t t,adder=0;
    OLED_SetPos(x,y);
    for(t=0;t<16;t++)
    {
        OLED_WriteDat(Hzk[2*no][t]);
        adder+=1;
    }
    OLED_SetPos(x,y+1);
    for(t=0;t<16;t++)
    {
        OLED_WriteDat(Hzk[2*no+1][t]);
        adder+=1;
    }
}

void OLED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    OLED_SCLK_Set();
    OLED_SDIN_Set();

    delay_ms(200);

    OLED_WriteCmd(0xAE);
    OLED_WriteCmd(0x20);
    OLED_WriteCmd(0x10);
    OLED_WriteCmd(0xB0);
    OLED_WriteCmd(0xC8);
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0x10);
    OLED_WriteCmd(0x40);
    OLED_WriteCmd(0x81);
    OLED_WriteCmd(0xFF);
    OLED_WriteCmd(0xA1);
    OLED_WriteCmd(0xA6);
    OLED_WriteCmd(0xA8);
    OLED_WriteCmd(0x1F);
    OLED_WriteCmd(0xA4);
    OLED_WriteCmd(0xD3);
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0xD5);
    OLED_WriteCmd(0xF0);
    OLED_WriteCmd(0xD9);
    OLED_WriteCmd(0x22);
    OLED_WriteCmd(0xDA);
    OLED_WriteCmd(0x02);
    OLED_WriteCmd(0xDB);
    OLED_WriteCmd(0x20);
    OLED_WriteCmd(0x8D);
    OLED_WriteCmd(0x14);
    OLED_WriteCmd(0xAF);

    OLED_Clear();
}
