#ifndef __OLED_H
#define __OLED_H
#include "stm32f4xx.h"
#include "sys.h"
#include "stdlib.h"

#define OLED_MODE 0
#define SIZE 8
#define XLevelL     0x00
#define XLevelH     0x10
#define Max_Column  128
#define Max_Row     64
#define Brightness  0xFF
#define X_WIDTH     128
#define Y_WIDTH     64

#define OLED_SCLK_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_6)//SCL
#define OLED_SCLK_Set() GPIO_SetBits(GPIOB,GPIO_Pin_6)

#define OLED_SDIN_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_9)//SDA
#define OLED_SDIN_Set() GPIO_SetBits(GPIOB,GPIO_Pin_9)

#define OLED_CMD  0
#define OLED_DATA 1

void OLED_WriteCmd(uint8_t cmd);
void OLED_WriteDat(uint8_t dat);
void OLED_Init(void);
void OLED_SetPos(uint8_t x, uint8_t y);
void OLED_ShowString(uint8_t x,uint8_t y,uint8_t *chr,uint8_t Char_Size);
void OLED_ShowCHinese(uint8_t x,uint8_t y,uint8_t no);
void OLED_Clear(void);

#endif
