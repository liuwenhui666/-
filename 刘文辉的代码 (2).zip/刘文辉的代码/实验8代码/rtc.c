#include "rtc.h"
#include "delay.h"  //简单延时

/**
  * @brief  RTC初始化配置
  * @note   通过BKP寄存器判断是否第一次配置RTC
  *         第一次配置时设置LSE时钟源、分频系数、初始时间和日期
  * @retval 0:成功, 1:LSE开启失败
  */
u8 BSP_RTC_Init(void)
{
    RTC_InitTypeDef RTC_InitStructure;
    u16 retry = 0X1FFF;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);  //使能PWR时钟
    PWR_BackupAccessCmd(ENABLE);       //使能后备寄存器访问

    /*根据BKP寄存器中的值,判断是否是第一次设置 RTC? (或者没有RTC电池)*/
    if(RTC_ReadBackupRegister(RTC_BKP_DR0) != 0x5050)
    {
        RCC_LSEConfig(RCC_LSE_ON);    //开启LSE
        /*检查指定的RCC标志位设置与否,等待低速晶振就绪*/
        while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
        {
            retry++;
            delay_ms(10);
        }
        if(retry==0)return 1;  //LSE 开启失败. 返回1

        /*设置RTC时钟(RTCCLK),选择LSE作为RTC时钟*/
        RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
        RCC_RTCCLKCmd(ENABLE);     //使能RTC时钟

        RTC_InitStructure.RTC_AsynchPrediv = 0x7F;   //RTC异步分频系数 (128)
        RTC_InitStructure.RTC_SynchPrediv  = 0xFF;  //RTC同步分频系数 (256)
        RTC_InitStructure.RTC_HourFormat  = RTC_HourFormat_24; //24小时格式
        RTC_Init(&RTC_InitStructure);

        RTC_Set_Time(13,00,00,RTC_H12_AM);     //设置时间: 13:00:00
        RTC_Set_Date(21,12,15,3);               //设置日期: 2021年12月15日 周三

        /*已经配置好,保存标志到RTC_BKP_DR0(电池保存)*/
        RTC_WriteBackupRegister(RTC_BKP_DR0,0x5050);
    }
    return 0;
}

/**
  * @brief  设置RTC时间
  * @param  hour: 小时 (0-23)
  * @param  min:  分钟 (0-59)
  * @param  sec:  秒   (0-59)
  * @param  ampm: AM/PM标志 (RTC_H12_AM 或 RTC_H12_PM)
  * @retval ErrorStatus: 成功或失败
  */
ErrorStatus RTC_Set_Time(u8 hour,u8 min,u8 sec,u8 ampm)
{
    RTC_TimeTypeDef RTC_TimeTypeInitStructure;

    RTC_TimeTypeInitStructure.RTC_Hours   = hour;
    RTC_TimeTypeInitStructure.RTC_Minutes = min;
    RTC_TimeTypeInitStructure.RTC_Seconds = sec;
    RTC_TimeTypeInitStructure.RTC_H12     = ampm;

    return RTC_SetTime(RTC_Format_BIN, &RTC_TimeTypeInitStructure);
}

/**
  * @brief  设置RTC日期
  * @param  year:  年 (0-99, 表示2000-2099)
  * @param  month: 月 (1-12)
  * @param  date:  日 (1-31)
  * @param  week:  星期 (1-7, 1=周一)
  * @retval ErrorStatus: 成功或失败
  */
ErrorStatus RTC_Set_Date(u8 year,u8 month,u8 date,u8 week)
{
    RTC_DateTypeDef RTC_DateTypeInitStructure;

    RTC_DateTypeInitStructure.RTC_Date    = date;
    RTC_DateTypeInitStructure.RTC_Month   = month;
    RTC_DateTypeInitStructure.RTC_WeekDay = week;
    RTC_DateTypeInitStructure.RTC_Year    = year;

    return RTC_SetDate(RTC_Format_BIN, &RTC_DateTypeInitStructure);
}
