/**
  ******************************************************************************
  * @file    usart.h
  * @brief   UART2 调试串口对外接口头文件
  * @note    AU100开发板 UART2: PA2(TX), PA3(RX)
  ******************************************************************************
  */

#ifndef __USART_H__
#define __USART_H__
#include "stm32f4xx.h"

void UART2_Init(u32 bound);

#endif
