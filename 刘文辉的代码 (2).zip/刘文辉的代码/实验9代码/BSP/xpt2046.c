/**
  ******************************************************************************
  * @file    xpt2046.c
  * @brief   XPT2046 触摸屏驱动实现源码
  * @note    基于AU100开发板 STM32F407, 使用GPIO模拟SPI总线
  *          引脚分配:
  *            CS   -> PD13
  *            CLK  -> PE0
  *            MOSI -> PE2
  *            MISO -> PE3
  *            IRQ  -> PE4
  ******************************************************************************
  */

#include <stdio.h>
#include <string.h>
#include "xpt2046.h"
#include "delay.h"

/*============================ 宏定义 ============================*/

#define XPT2046_CHANNEL_X     0xD0  // 通道X+的选择控制字
#define XPT2046_CHANNEL_Y     0x90  // 通道Y+的选择控制字

#define TOUCH_PRESSED         1
#define TOUCH_NOT_PRESSED     0

#define XPT2046_PENIRQ_Active        0     // 触摸按下时IRQ为低电平
#define XPT2046_THRESHOLD_CalDiff    2     // 校准触摸屏时触摸坐标的AD值相差门限
#define DURIATION_TIME               2     // 消抖时间计数阈值

/*============================ SPI引脚操作宏 ============================*/

#define XPT2046_CS_ENABLE()    GPIO_ResetBits(GPIOD, GPIO_Pin_13)
#define XPT2046_CS_DISABLE()   GPIO_SetBits(GPIOD, GPIO_Pin_13)

#define XPT2046_CLK_HIGH()     GPIO_SetBits(GPIOE, GPIO_Pin_0)
#define XPT2046_CLK_LOW()      GPIO_ResetBits(GPIOE, GPIO_Pin_0)

#define XPT2046_MOSI_1()       GPIO_SetBits(GPIOE, GPIO_Pin_2)
#define XPT2046_MOSI_0()       GPIO_ResetBits(GPIOE, GPIO_Pin_2)

#define XPT2046_MISO()         GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3)
#define XPT2046_ReadIRQ()      GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4)

#define XPT2046_DelayUS(x)    delay_us(x)

/*============================ 全局变量 ============================*/

// 当前使用的LCD扫描方式，需与LCD驱动的值一致
int LCD_SCAN_MODE = 0;

// 默认触摸参数，不同的屏幕稍有差异，可重新调用触摸校准函数获取
XPT2046_Factor TouchFactor[] = {
    -0.006464,   -0.073259,  280.358032,    0.074878,    0.002052,   -6.545977,  // 扫描方式0
     0.086314,    0.001891,  -12.836658,   -0.003722,   -0.065799,  254.715714,  // 扫描方式1
     0.002782,    0.061522,  -11.595689,    0.083393,    0.005159,  -15.650089,  // 扫描方式2
     0.089743,   -0.000289,  -20.612209,   -0.001374,    0.064451,  -16.054003,  // 扫描方式3
     0.000767,   -0.068258,  250.891769,   -0.085559,   -0.000195,  334.747650,  // 扫描方式4
    -0.084744,    0.000047,  323.163147,   -0.002109,   -0.066371,  260.985809,  // 扫描方式5
    -0.001848,    0.066984,  -12.807136,   -0.084858,   -0.000805,  333.395386,  // 扫描方式6
    -0.085470,   -0.000876,  334.023163,   -0.003390,    0.064725,   -6.211169,  // 扫描方式7
};

/*============================ 内部函数声明 ============================*/

static void    XPT2046_WriteCMD(uint8_t ucCmd);
static uint16_t XPT2046_ReadCMD(void);
static uint16_t XPT2046_ReadAdc(uint8_t ucChannel);
static void    XPT2046_ReadAdcXY(uint16_t *sX_Ad, uint16_t *sY_Ad);
static int8_t  XPT2046_FilterXY(XPT2046_Coord *pCoord);

/*============================ GPIO初始化 ============================*/

/**
  * @brief  XPT2046 初始化函数
  * @param  无
  * @retval 无
  */
void XPT2046_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    // 开启GPIO时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD | RCC_AHB1Periph_GPIOE, ENABLE);

    // SPI CLK (PE0)
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    // SPI MOSI (PE2)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    // SPI CS (PD13)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    // MISO (PE3) - 输入模式
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd   = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    // IRQ (PE4) - 输入模式
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    // 拉低片选，选择XPT2046
    XPT2046_CS_ENABLE();
}

/*============================ SPI底层操作 ============================*/

/**
  * @brief  XPT2046 写入命令
  * @param  ucCmd : 命令字节
  *   该参数为以下值之一：
  *     @arg 0x90 : 通道Y+的选择控制字
  *     @arg 0xD0 : 通道X+的选择控制字
  * @retval 无
  */
static void XPT2046_WriteCMD(uint8_t ucCmd)
{
    uint8_t i = 0;

    XPT2046_MOSI_0();
    XPT2046_CLK_LOW();

    for (i = 0; i < 8; i++) {
        ((ucCmd >> (7 - i)) & 0x01) ? XPT2046_MOSI_1() : XPT2046_MOSI_0();
        XPT2046_DelayUS(5);
        XPT2046_CLK_HIGH();
        XPT2046_DelayUS(5);
        XPT2046_CLK_LOW();
    }
}

/**
  * @brief  XPT2046 读取12位ADC数据
  * @param  无
  * @retval 读取到的12位数据
  */
static uint16_t XPT2046_ReadCMD(void)
{
    uint8_t i;
    uint16_t usBuf = 0, usTemp;

    XPT2046_MOSI_0();
    XPT2046_CLK_HIGH();

    for (i = 0; i < 12; i++) {
        XPT2046_CLK_LOW();
        usTemp = XPT2046_MISO();
        usBuf |= usTemp << (11 - i);
        XPT2046_CLK_HIGH();
    }
    return usBuf;
}

/**
  * @brief  对XPT2046选择一个模拟通道后，启动ADC，并返回ADC采样结果
  * @param  ucChannel : 通道选择控制字
  *   该参数为以下值之一：
  *     @arg 0x90 : 通道Y+
  *     @arg 0xD0 : 通道X+
  * @retval 该通道的ADC采样结果 (12位, 最大4096)
  */
static uint16_t XPT2046_ReadAdc(uint8_t ucChannel)
{
    XPT2046_WriteCMD(ucChannel);
    return XPT2046_ReadCMD();
}

/**
  * @brief  读取XPT2046的X通道和Y通道的AD值
  * @param  sX_Ad : 存放X通道AD值的地址
  * @param  sY_Ad : 存放Y通道AD值的地址
  * @retval 无
  */
static void XPT2046_ReadAdcXY(uint16_t *sX_Ad, uint16_t *sY_Ad)
{
    *sX_Ad = XPT2046_ReadAdc(XPT2046_CHANNEL_X);
    XPT2046_DelayUS(1);
    *sY_Ad = XPT2046_ReadAdc(XPT2046_CHANNEL_Y);
}

/*============================ 滤波算法 ============================*/

/**
  * @brief  对XPT2046 ADC值进行滤波处理
  * @param  pCoord : 存放滤波后的坐标
  * @retval 0-成功, -1-失败(采样不足)
  * @note   算法: 采集10组数据, 去掉最大最小值, 剩余8组取平均
  */
static int8_t XPT2046_FilterXY(XPT2046_Coord *pCoord)
{
    uint8_t ucCount = 0, i = 0;
    uint16_t value = 0;
    uint16_t tempAD_X, tempAD_Y = 0;
    uint16_t sBufferArray[2][10] = { {0}, {0} };
    uint32_t lX_Min, lX_Max, lY_Min, lY_Max = 0;

    do {
        XPT2046_ReadAdcXY(&tempAD_X, &tempAD_Y);
        sBufferArray[0][ucCount] = tempAD_X;
        sBufferArray[1][ucCount] = tempAD_Y;
        ucCount++;
        value = XPT2046_ReadIRQ();
    } while ((value == XPT2046_PENIRQ_Active) && (ucCount < 10));

    if (ucCount < 10) {
        return -1;  // 未采样10个样本，无效
    }

    lX_Max = lX_Min = sBufferArray[0][0];
    lY_Max = lY_Min = sBufferArray[1][0];
    tempAD_X = sBufferArray[0][0];
    tempAD_Y = sBufferArray[1][0];

    // 找出X轴最小最大值并累加
    for (i = 1; i < 10; i++) {
        if (sBufferArray[0][i] < lX_Min) {
            lX_Min = sBufferArray[0][i];
        } else if (sBufferArray[0][i] > lX_Max) {
            lX_Max = sBufferArray[0][i];
        }
        tempAD_X += sBufferArray[0][i];
    }

    // 找出Y轴最小最大值并累加
    for (i = 1; i < 10; i++) {
        if (sBufferArray[1][i] < lY_Min) {
            lY_Min = sBufferArray[1][i];
        } else if (sBufferArray[1][i] > lY_Max) {
            lY_Max = sBufferArray[1][i];
        }
        tempAD_Y += sBufferArray[1][i];
    }

    // 去除最小值和最大值之后求平均值 (8组求平均, 右移3位)
    pCoord->x = (tempAD_X - lX_Min - lX_Max) >> 3;
    pCoord->y = (tempAD_Y - lY_Min - lY_Max) >> 3;

    return 0;
}

/*============================ 坐标转换 ============================*/

/**
  * @brief  获取XPT2046触摸点（校准后）的坐标
  * @param  pLCD : 该指针存放获取到的触摸点LCD坐标
  * @retval 0-成功, -1-失败
  * @note   使用三点校准公式: XL = A*x + B*y + C, YL = D*x + E*y + F
  */
int8_t XPT2046_GetTouchPoint(XPT2046_Coord *pLCD)
{
    XPT2046_Coord adcCoord;

    if (XPT2046_FilterXY(&adcCoord) < 0) {
        return -1;
    }

    // XL = AX + BY + C
    pLCD->x = TouchFactor[LCD_SCAN_MODE].A * adcCoord.x +
              TouchFactor[LCD_SCAN_MODE].B * adcCoord.y +
              TouchFactor[LCD_SCAN_MODE].C;

    // YL = DX + EY + F
    pLCD->y = TouchFactor[LCD_SCAN_MODE].D * adcCoord.x +
              TouchFactor[LCD_SCAN_MODE].E * adcCoord.y +
              TouchFactor[LCD_SCAN_MODE].F;

    return 0;
}

/**
  * @brief  计算校准因子 (三点校准法)
  * @param  pLCD   : 三个LCD坐标点
  * @param  pTouch : 三个触摸ADC坐标点
  * @param  pFactor : 计算得到的校准因子
  * @retval 0-成功
  */
int8_t XPT2046_CalibrationFactor(XPT2046_Coord *pLCD, XPT2046_Coord *pTouch, XPT2046_Factor *pFactor)
{
    // 使用最小二乘法求解校准参数
    // 此函数保留接口，实际校准可由应用层实现
    (void)pLCD;
    (void)pTouch;
    (void)pFactor;
    return 0;
}

/*============================ 触摸回调函数 ============================*/

/**
  * @brief  触摸屏被按下时的回调函数 (__weak, 可重写)
  * @param  touch : 包含触摸坐标的结构体
  * @retval 无
  */
__weak void XPT2046_TouchDown(XPT2046_Coord *touch)
{
    printf("TouchDown, x:%d, y:%d\r\n", touch->x, touch->y);
}

/**
  * @brief  触摸屏释放时的回调函数 (__weak, 可重写)
  * @param  touch : 包含触摸坐标的结构体
  * @retval 无
  */
__weak void XPT2046_TouchUp(XPT2046_Coord *touch)
{
    printf("TouchUp, x:%d, y:%d\r\n", touch->x, touch->y);
}

/*============================ 触摸事件检测 ============================*/

/**
  * @brief  触摸屏检测状态机
  * @retval TOUCH_PRESSED : 触摸按下
  *         TOUCH_NOT_PRESSED : 无触摸
  * @note   包含消抖处理，建议在定时器中每10ms调用一次
  *         消抖时间 = DURIATION_TIME * 调用间隔
  */
uint8_t XPT2046_DetectTouch(void)
{
    uint8_t detectResult = TOUCH_NOT_PRESSED;
    uint16_t value = 0;
    static uint32_t i = 0;
    static enumTouchState touch_state = XPT2046_STATE_RELEASE;
    static XPT2046_Coord cinfo = {-1, -1, -1, -1};

    value = XPT2046_ReadIRQ();

    switch (touch_state) {
        case XPT2046_STATE_RELEASE:
            if (value == XPT2046_PENIRQ_Active) {
                touch_state  = XPT2046_STATE_WAITING;
                detectResult = TOUCH_NOT_PRESSED;
            } else {
                touch_state  = XPT2046_STATE_RELEASE;
                detectResult = TOUCH_NOT_PRESSED;
            }
            break;

        case XPT2046_STATE_WAITING:
            if (value == XPT2046_PENIRQ_Active) {
                i++;
                if (i > DURIATION_TIME) {
                    i = 0;
                    touch_state  = XPT2046_STATE_PRESSED;
                    detectResult = TOUCH_PRESSED;
                } else {
                    touch_state  = XPT2046_STATE_WAITING;
                    detectResult = TOUCH_NOT_PRESSED;
                }
            } else {
                i = 0;
                touch_state  = XPT2046_STATE_RELEASE;
                detectResult = TOUCH_NOT_PRESSED;
            }
            break;

        case XPT2046_STATE_PRESSED:
            if (value == XPT2046_PENIRQ_Active) {
                touch_state  = XPT2046_STATE_PRESSED;
                detectResult = TOUCH_PRESSED;
            } else {
                touch_state  = XPT2046_STATE_RELEASE;
                detectResult = TOUCH_NOT_PRESSED;
            }
            break;

        default:
            touch_state  = XPT2046_STATE_RELEASE;
            detectResult = TOUCH_NOT_PRESSED;
            break;
    }

    if (detectResult == TOUCH_PRESSED) {
        if (XPT2046_GetTouchPoint(&cinfo) < 0) {
            return detectResult;
        }
        XPT2046_TouchDown(&cinfo);
        cinfo.pre_x = cinfo.x;
        cinfo.pre_y = cinfo.y;
    } else {
        if (cinfo.pre_x == -1 && cinfo.pre_y == -1) {
            return detectResult;
        }
        XPT2046_TouchUp(&cinfo);
        cinfo.x = -1;
        cinfo.y = -1;
        cinfo.pre_x = -1;
        cinfo.pre_y = -1;
    }

    return detectResult;
}
