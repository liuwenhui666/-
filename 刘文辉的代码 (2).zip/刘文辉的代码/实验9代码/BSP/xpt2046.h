/**
  ******************************************************************************
  * @file    xpt2046.h
  * @brief   XPT2046 触摸屏控制器对外接口头文件
  * @note    基于AU100开发板 STM32F407, GPIO模拟SPI
  ******************************************************************************
  */

#ifndef __XPT2046_H__
#define __XPT2046_H__
#include "stm32f4xx.h"

/**
  * @brief 液晶坐标结构体
  */
typedef struct {
    int16_t x;       // 记录最新的触摸参数值（负数值表示无新数据）
    int16_t y;

    int16_t pre_x;   // 用于记录连续触摸时(长按)的上一次触摸位置
    int16_t pre_y;
} XPT2046_Coord;

/**
  * @brief 校准因子结构体 (三点校准法)
  * @note  公式: XL = A*x + B*y + C
  *         YL = D*x + E*y + F
  */
typedef struct {
    long double A;
    long double B;
    long double C;
    long double D;
    long double E;
    long double F;
} XPT2046_Factor;

/**
  * @brief 触摸状态枚举
  */
typedef enum {
    XPT2046_STATE_RELEASE  = 0,  // 释放状态
    XPT2046_STATE_WAITING,       // 等待确认（消抖中）
    XPT2046_STATE_PRESSED,       // 按下状态
} enumTouchState;

void    XPT2046_Init(void);
uint8_t XPT2046_DetectTouch(void);
int8_t  XPT2046_GetTouchPoint(XPT2046_Coord *displayPtr);
int8_t  XPT2046_CalibrationFactor(XPT2046_Coord *pLCD, XPT2046_Coord *pTouch, XPT2046_Factor *pFactor);

#endif /* __XPT2046_H__ */
