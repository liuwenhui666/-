#include <stdio.h>
#include "stm32f4xx.h"
#include "xpt2046.h"
#include "usart.h"
#include "delay.h"

/**
  * @brief  系统时钟配置：HSE(8MHz) -> PLL -> 168MHz
  * @param  无
  * @retval 无
  */
void SystemClock_Config(void)
{
    RCC_ClocksTypeDef RCC_Clocks;

    // 复位时钟配置
    RCC_DeInit();

    // 使能 HSE（外部8MHz晶振）
    RCC_HSEConfig(RCC_HSE_ON);
    // 等待 HSE 就绪
    while (RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET);

    // 配置 PLL：HSE -> /8 -> *336 -> /2 = 168MHz
    // PLL_M=8, PLL_N=336, PLL_P=2, PLL_Q=7
    RCC_PLLConfig(RCC_PLLSource_HSE, 8, 336, 2, 7);
    RCC_PLLCmd(ENABLE);
    // 等待 PLL 就绪
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);

    // 配置 Flash 等待周期（168MHz 需要 5 个等待周期）
    FLASH_SetLatency(FLASH_Latency_5);
    FLASH_PrefetchBufferCmd(ENABLE);
    FLASH_InstructionCacheCmd(ENABLE);
    FLASH_DataCacheCmd(ENABLE);

    // 切换系统时钟到 PLL
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
    // 等待 PLL 成为系统时钟源
    while (RCC_GetSYSCLKSource() != 0x08);

    // HCLK = SYSCLK = 168MHz
    RCC_HCLKConfig(RCC_SYSCLK_Div1);
    // PCLK2(APB2) = HCLK/2 = 84MHz
    RCC_PCLK2Config(RCC_HCLK_Div2);
    // PCLK1(APB1) = HCLK/4 = 42MHz
    RCC_PCLK1Config(RCC_HCLK_Div4);

    // 验证系统时钟
    RCC_GetClocksFreq(&RCC_Clocks);
}

/**
  * @brief  主函数
  * @param  无
  * @retval 无
  */
int main(void) {
    SystemClock_Config();   // 配置系统时钟到 168MHz
    delay_init(168);        // 延时函数初始化（168MHz）
    UART2_Init(115200);     // 调试串口，方便打印
    
    XPT2046_Init();
    printf("XPT2046 TEST\r\n"); 
    
    while(1){
        XPT2046_DetectTouch();
        delay_ms(10);
    }
}
