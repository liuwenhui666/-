#ifndef __BEEP_H
#define __BEEP_H

#include "stm32f4xx.h"

/* 蜂鸣器: PA8 (有源蜂鸣器, 低电平响) */
#define BEEP_PORT   GPIOA
#define BEEP_PIN    GPIO_Pin_8

#define BEEP_ON()   GPIO_ResetBits(BEEP_PORT, BEEP_PIN)
#define BEEP_OFF()  GPIO_SetBits(BEEP_PORT, BEEP_PIN)

void BEEP_Init(void);

#endif
