#include "debug.h"
#include "usart.h"
#include <stdarg.h>

/**
 * @brief 初始化调试串口 (复用USART2)
 * @param baud 波特率
 */
void Debug_Init(uint32_t baud)
{
    UART2_Init(baud);
}

/**
 * @brief printf 风格的调试输出
 */
void Debug_Print(const char *fmt, ...)
{
    char buf[128];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    char *p = buf;
    while (*p) {
        USART_SendData(USART2, *p);
        while (USART_GetFlagStatus(USART2, USART_FLAG_TC) == RESET);
        p++;
    }
}
