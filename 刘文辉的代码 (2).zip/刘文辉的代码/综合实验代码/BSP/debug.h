#ifndef __DEBUG_H
#define __DEBUG_H

#include "stm32f4xx.h"
#include <stdio.h>

/* 串口调试打印 - 课堂上配合串口助手展示数据流 */
void Debug_Init(uint32_t baud);
void Debug_Print(const char *fmt, ...);

#endif
