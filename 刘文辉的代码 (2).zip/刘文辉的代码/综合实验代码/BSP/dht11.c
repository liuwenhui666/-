/**
 * @file    dht11.c
 * @brief   DHT11温湿度传感器驱动 (PE6, 参考官方实验代码)
 */
#include <stddef.h>

#include "dht11.h"
#include "delay.h"

/* 模式切换 */
static void DHT11_Mode_IN(void)
{
    GPIO_InitTypeDef gpio;
    gpio.GPIO_Pin   = DHT11_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_IN;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    gpio.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_Init(DHT11_PORT, &gpio);
}

static void DHT11_Mode_OUT(void)
{
    GPIO_InitTypeDef gpio;
    gpio.GPIO_Pin   = DHT11_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd  = GPIO_PuPd_NOPULL;
    gpio.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_Init(DHT11_PORT, &gpio);
}

/* 等待指定电平 */
static int8_t DHT11_WaitFor(BitAction bitValue, uint32_t max_us)
{
    uint8_t try_num = 0;
    while ((GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN) != bitValue)
           && try_num < max_us) {
        try_num++;
        delay_us(1);
    }
    if (try_num >= max_us) return -1;
    return 0;
}

/* 读取一个位 */
static int8_t DHT11_ReadBit(void)
{
    if (DHT11_WaitFor(Bit_RESET, 100) < 0) return -1;
    if (DHT11_WaitFor(Bit_SET, 100) < 0)  return -1;
    delay_us(40);
    if (GPIO_ReadInputDataBit(DHT11_PORT, DHT11_PIN) == Bit_SET)
        return 1;
    else
        return 0;
}

/* 读取一个字节 */
static uint8_t DHT11_ReadByte(void)
{
    uint8_t byte = 0;
    uint8_t i;
    for (i = 0; i < 8; i++) {
        byte <<= 1;
        byte |= DHT11_ReadBit();
    }
    return byte;
}

/**
 * @brief DHT11 初始化
 */
void DHT11_Init(void)
{
    RCC_AHB1PeriphClockCmd(DHT11_CLK, ENABLE);
    DHT11_Mode_OUT();
    GPIO_SetBits(DHT11_PORT, DHT11_PIN);
}

/**
 * @brief 读取DHT11数据
 * @retval 0=成功, -1=失败
 */
int8_t DHT11_ReadData(DHT11_Data *pData)
{
    if (pData == NULL) return -1;

    /* 起始信号 */
    DHT11_Mode_OUT();
    GPIO_SetBits(DHT11_PORT, DHT11_PIN);
    GPIO_ResetBits(DHT11_PORT, DHT11_PIN);
    delay_ms(18);
    GPIO_SetBits(DHT11_PORT, DHT11_PIN);
    delay_us(30);

    /* 切换输入, 等待DHT11响应 */
    DHT11_Mode_IN();
    if (DHT11_WaitFor(Bit_RESET, 200) < 0) { pData->valid = 0; return -1; }
    if (DHT11_WaitFor(Bit_SET, 100) < 0)   { pData->valid = 0; return -1; }
    delay_us(80);

    /* 读取5字节 */
    pData->humi_int  = DHT11_ReadByte();
    pData->humi_deci = DHT11_ReadByte();
    pData->temp_int  = DHT11_ReadByte();
    pData->temp_deci = DHT11_ReadByte();
    pData->check_sum = DHT11_ReadByte();

    /* 校验 */
    if (pData->check_sum !=
        pData->humi_int + pData->humi_deci + pData->temp_int + pData->temp_deci) {
        pData->valid = 0;
        return -1;
    }

    pData->valid = 1;
    return 0;
}
