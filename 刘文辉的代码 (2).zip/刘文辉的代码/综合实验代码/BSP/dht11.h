#ifndef __DHT11_H
#define __DHT11_H

#include "stm32f4xx.h"

/* 数据引脚: PE6 (DHT11温湿度传感器) */
#define DHT11_PORT      GPIOE
#define DHT11_PIN       GPIO_Pin_6
#define DHT11_CLK       RCC_AHB1Periph_GPIOE

/* 传感器数据结构 */
typedef struct {
    uint8_t humi_int;      /* 湿度整数 */
    uint8_t humi_deci;     /* 湿度小数 */
    uint8_t temp_int;      /* 温度整数 */
    uint8_t temp_deci;     /* 温度小数 */
    uint8_t check_sum;     /* 校验和 */
    uint8_t valid;         /* 1=数据有效, 0=读取失败 */
} DHT11_Data;

/* 函数声明 */
void    DHT11_Init(void);
int8_t  DHT11_ReadData(DHT11_Data *data);

#endif
