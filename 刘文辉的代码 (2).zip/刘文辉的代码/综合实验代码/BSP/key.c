#include "key.h"

/**
 * @brief 按键初始化 (PA0, PC13, PH2, PH3 上拉输入)
 */
void KEY_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOC, ENABLE);

    gpio.GPIO_Mode = GPIO_Mode_IN;
    gpio.GPIO_PuPd = GPIO_PuPd_UP;

    gpio.GPIO_Pin = KEY1_PIN;
    GPIO_Init(KEY1_PORT, &gpio);
    gpio.GPIO_Pin = KEY2_PIN;
    GPIO_Init(KEY2_PORT, &gpio);
    gpio.GPIO_Pin = KEY3_PIN;
    GPIO_Init(KEY3_PORT, &gpio);
    gpio.GPIO_Pin = KEY4_PIN;
    GPIO_Init(KEY4_PORT, &gpio);
}

/**
 * @brief 读取按键状态 (无消抖, 由调用方处理)
 * @param num 按键号 1-4
 * @retval KEY_DOWN=按下, KEY_UP=松开
 */
uint8_t KEY_Read(uint8_t num)
{
    switch (num) {
        case 1:  return GPIO_ReadInputDataBit(KEY1_PORT, KEY1_PIN);
        case 2:  return GPIO_ReadInputDataBit(KEY2_PORT, KEY2_PIN);
        case 3:  return GPIO_ReadInputDataBit(KEY3_PORT, KEY3_PIN);
        case 4:  return GPIO_ReadInputDataBit(KEY4_PORT, KEY4_PIN);
        default: return KEY_UP;
    }
}
