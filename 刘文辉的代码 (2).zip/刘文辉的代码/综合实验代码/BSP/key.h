#ifndef __KEY_H
#define __KEY_H

#include "stm32f4xx.h"

/* KEY1: PA0, KEY2: PC13, KEY3: PC6, KEY4: PC7 (按下为低电平) */
#define KEY1_PORT   GPIOA
#define KEY1_PIN    GPIO_Pin_0
#define KEY2_PORT   GPIOC
#define KEY2_PIN    GPIO_Pin_13
#define KEY3_PORT   GPIOC
#define KEY3_PIN    GPIO_Pin_6
#define KEY4_PORT   GPIOC
#define KEY4_PIN    GPIO_Pin_7

#define KEY_DOWN    0   /* 按下 */
#define KEY_UP      1   /* 松开 */

void KEY_Init(void);
uint8_t KEY_Read(uint8_t num);    /* num: 1-4 */

#endif
