#include "led.h"

/**
 * @brief LED初始化 (PF9, PF10, PC0 推挽输出, 默认熄灭)
 */
void LED_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    gpio.GPIO_Mode  = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_PuPd  = GPIO_PuPd_UP;

    gpio.GPIO_Pin = LED1_PIN;
    GPIO_Init(LED1_PORT, &gpio);
    gpio.GPIO_Pin = LED2_PIN;
    GPIO_Init(LED2_PORT, &gpio);
    gpio.GPIO_Pin = LED3_PIN;
    GPIO_Init(LED3_PORT, &gpio);

    LED_AllOff();
}

void LED_AllOff(void)
{
    LED1_OFF();
    LED2_OFF();
    LED3_OFF();
}
