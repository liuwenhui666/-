#ifndef __LED_H
#define __LED_H

#include "stm32f4xx.h"

/* LED1: PB5, LED2: PB0, LED3: PB1 (低电平点亮) */
#define LED1_PORT   GPIOB
#define LED1_PIN    GPIO_Pin_5
#define LED2_PORT   GPIOB
#define LED2_PIN    GPIO_Pin_0
#define LED3_PORT   GPIOB
#define LED3_PIN    GPIO_Pin_1

#define LED1_ON()   GPIO_ResetBits(LED1_PORT, LED1_PIN)
#define LED1_OFF()  GPIO_SetBits(LED1_PORT, LED1_PIN)
#define LED2_ON()   GPIO_ResetBits(LED2_PORT, LED2_PIN)
#define LED2_OFF()  GPIO_SetBits(LED2_PORT, LED2_PIN)
#define LED3_ON()   GPIO_ResetBits(LED3_PORT, LED3_PIN)
#define LED3_OFF()  GPIO_SetBits(LED3_PORT, LED3_PIN)

void LED_Init(void);
void LED_AllOff(void);

#endif
