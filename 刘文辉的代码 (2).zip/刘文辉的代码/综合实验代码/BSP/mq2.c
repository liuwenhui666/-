#include "mq2.h"

/**
 * @brief MQ-2 初始化 (PA1, ADC1)
 */
void MQ2_Init(void)
{
    GPIO_InitTypeDef       GPIO_InitStructure;
    ADC_InitTypeDef        ADC_InitStructure;
    ADC_CommonInitTypeDef  ADC_CommonInitStructure;

    /* 时钟 */
    RCC_AHB1PeriphClockCmd(MQ2_GPIO_CLK, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);

    /* PA1 模拟输入 */
    GPIO_InitStructure.GPIO_Pin  = MQ2_GPIO_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(MQ2_GPIO_PORT, &GPIO_InitStructure);

    /* ADC 通用配置 */
    ADC_CommonInitStructure.ADC_Mode             = ADC_Mode_Independent;
    ADC_CommonInitStructure.ADC_Prescaler        = ADC_Prescaler_Div4;
    ADC_CommonInitStructure.ADC_DMAAccessMode    = ADC_DMAAccessMode_Disabled;
    ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    ADC_CommonInit(&ADC_CommonInitStructure);

    /* ADC1 配置 */
    ADC_InitStructure.ADC_Resolution           = ADC_Resolution_12b;
    ADC_InitStructure.ADC_ScanConvMode         = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode   = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    ADC_InitStructure.ADC_DataAlign            = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfConversion      = 1;
    ADC_Init(MQ2_ADC, &ADC_InitStructure);

    /* 配置通道 */
    ADC_RegularChannelConfig(MQ2_ADC, MQ2_ADC_CH, 1, ADC_SampleTime_480Cycles);

    ADC_Cmd(MQ2_ADC, ENABLE);
}

/**
 * @brief 读取MQ-2 ADC原始值 (0-4095)
 */
uint16_t MQ2_Read(void)
{
    ADC_SoftwareStartConv(MQ2_ADC);
    while (ADC_GetFlagStatus(MQ2_ADC, ADC_FLAG_EOC) == RESET);
    return ADC_GetConversionValue(MQ2_ADC);
}

/**
 * @brief 获取烟雾浓度等级
 */
SmokeLevel MQ2_GetLevel(void)
{
    uint16_t val = MQ2_Read();
    if (val > MQ2_ALARM_HIGH) return SMOKE_DANGER;
    if (val > MQ2_ALARM_LOW)  return SMOKE_WARN;
    return SMOKE_SAFE;
}
