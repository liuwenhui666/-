#ifndef __MQ2_H
#define __MQ2_H

#include "stm32f4xx.h"

/* 使用 PC1 作为模拟输入 (ADC1 通道11) */
#define MQ2_GPIO_PORT   GPIOC
#define MQ2_GPIO_PIN    GPIO_Pin_1
#define MQ2_GPIO_CLK    RCC_AHB1Periph_GPIOC
#define MQ2_ADC         ADC1
#define MQ2_ADC_CH      ADC_Channel_11

/* 报警阈值(可调) */
#define MQ2_ALARM_HIGH  3000    /* 高浓度报警 */
#define MQ2_ALARM_LOW   1500    /* 低浓度预警 */

/* 烟雾等级 */
typedef enum {
    SMOKE_SAFE = 0,     /* 安全 */
    SMOKE_WARN = 1,     /* 预警 */
    SMOKE_DANGER = 2    /* 危险 */
} SmokeLevel;

void MQ2_Init(void);
uint16_t MQ2_Read(void);
SmokeLevel MQ2_GetLevel(void);

#endif
