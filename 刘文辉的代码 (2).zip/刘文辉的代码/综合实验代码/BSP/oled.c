#include "oled.h"
#include "oledfont.h"
#include "delay.h"

/* I2C 宏 */
#define SCL_H()     GPIO_SetBits(OLED_SCL_PORT, OLED_SCL_PIN)
#define SCL_L()     GPIO_ResetBits(OLED_SCL_PORT, OLED_SCL_PIN)
#define SDA_H()     GPIO_SetBits(OLED_SDA_PORT, OLED_SDA_PIN)
#define SDA_L()     GPIO_ResetBits(OLED_SDA_PORT, OLED_SDA_PIN)

static void I2C_Delay(void)
{
    uint8_t i;
    for (i = 0; i < 15; i++) { __NOP(); }
}

static void I2C_Start(void)
{
    SDA_H(); I2C_Delay();
    SCL_H(); I2C_Delay();
    SDA_L(); I2C_Delay();
    SCL_L(); I2C_Delay();
}

static void I2C_Stop(void)
{
    SDA_L(); I2C_Delay();
    SCL_H(); I2C_Delay();
    SDA_H(); I2C_Delay();
}

static void I2C_SendByte(uint8_t dat)
{
    uint8_t i;
    for (i = 0; i < 8; i++) {
        if (dat & 0x80) SDA_H(); else SDA_L();
        dat <<= 1;
        I2C_Delay();
        SCL_H(); I2C_Delay();
        SCL_L(); I2C_Delay();
    }
    SDA_H(); I2C_Delay();     /* 释放SDA */
    SCL_H(); I2C_Delay();     /* 等待ACK */
    SCL_L(); I2C_Delay();
}

static void OLED_WriteCmd(uint8_t cmd)
{
    I2C_Start();
    I2C_SendByte(OLED_ADDR);
    I2C_SendByte(0x00);     /* 控制字节: 命令 */
    I2C_SendByte(cmd);
    I2C_Stop();
}

static void OLED_WriteData(uint8_t dat)
{
    I2C_Start();
    I2C_SendByte(OLED_ADDR);
    I2C_SendByte(0x40);     /* 控制字节: 数据 */
    I2C_SendByte(dat);
    I2C_Stop();
}

/**
 * @brief OLED 初始化
 */
void OLED_Init(void)
{
    GPIO_InitTypeDef gpio;
    RCC_AHB1PeriphClockCmd(OLED_I2C_CLK, ENABLE);

    gpio.GPIO_Pin   = OLED_SCL_PIN | OLED_SDA_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_OD;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(OLED_SCL_PORT, &gpio);

    SCL_H(); SDA_H();
    delay_ms(100);

    OLED_WriteCmd(0xAE); /* 关闭显示 */
    OLED_WriteCmd(0xD5); OLED_WriteCmd(0x80); /* 时钟分频 */
    OLED_WriteCmd(0xA8); OLED_WriteCmd(0x3F); /* 多路复用 64行 */
    OLED_WriteCmd(0xD3); OLED_WriteCmd(0x00); /* 显示偏移 */
    OLED_WriteCmd(0x40); /* 起始行 */
    OLED_WriteCmd(0xA1); /* 段重映射 (左右翻转) */
    OLED_WriteCmd(0xC8); /* COM扫描方向 (上下翻转) */
    OLED_WriteCmd(0xDA); OLED_WriteCmd(0x12); /* COM引脚配置 */
    OLED_WriteCmd(0x81); OLED_WriteCmd(0xCF); /* 对比度 */
    OLED_WriteCmd(0xD9); OLED_WriteCmd(0xF1); /* 预充电 */
    OLED_WriteCmd(0xDB); OLED_WriteCmd(0x40); /* VCOMH */
    OLED_WriteCmd(0xA4); /* 全局显示开启 */
    OLED_WriteCmd(0xA6); /* 正常显示(非反色) */
    OLED_WriteCmd(0x8D); OLED_WriteCmd(0x14); /* 电荷泵 */
    OLED_WriteCmd(0xAF); /* 开启显示 */

    OLED_Clear();
}

/**
 * @brief 清屏
 */
void OLED_Clear(void)
{
    uint8_t i, j;
    for (i = 0; i < 8; i++) {
        OLED_WriteCmd(0xB0 + i);
        OLED_WriteCmd(0x00);
        OLED_WriteCmd(0x10);
        for (j = 0; j < 128; j++) {
            OLED_WriteData(0x00);
        }
    }
}

/**
 * @brief 设置光标位置
 */
static void OLED_SetPos(uint8_t x, uint8_t y)
{
    OLED_WriteCmd(0xB0 + y);
    OLED_WriteCmd(((x & 0xF0) >> 4) | 0x10);
    OLED_WriteCmd(x & 0x0F);
}

/**
 * @brief 显示字符 (size=12: 6x12, size=16: 8x16)
 */
static void OLED_ShowChar(uint8_t x, uint8_t y, char ch, uint8_t size)
{
    uint8_t i, idx = ch - ' ';
    if (idx > 94) idx = 0;

    if (size == 16) {
        OLED_SetPos(x, y);
        for (i = 0; i < 8; i++) OLED_WriteData(F8X16[idx * 16 + i]);
        OLED_SetPos(x, y + 1);
        for (i = 0; i < 8; i++) OLED_WriteData(F8X16[idx * 16 + i + 8]);
    } else {
        OLED_SetPos(x, y);
        for (i = 0; i < 6; i++) OLED_WriteData(F6x8[idx][i]);
    }
}

/**
 * @brief 显示字符串
 */
void OLED_ShowStr(uint8_t x, uint8_t y, const char *str, uint8_t size)
{
    while (*str) {
        if (x > 120) { x = 0; y += (size == 16 ? 2 : 1); }
        OLED_ShowChar(x, y, *str, size);
        x += (size == 16 ? 8 : 6);
        str++;
    }
}

/**
 * @brief 显示无符号整数
 */
void OLED_ShowNum(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size)
{
    char buf[12];
    uint8_t i;
    for (i = 0; i < len; i++) {
        buf[len - 1 - i] = (num % 10) + '0';
        num /= 10;
    }
    buf[len] = '\0';
    OLED_ShowStr(x, y, buf, size);
}

/**
 * @brief 显示浮点数 (保留decLen位小数)
 */
void OLED_ShowFloat(uint8_t x, uint8_t y, float num, uint8_t intLen, uint8_t decLen, uint8_t size)
{
    char buf[16];
    int intPart = (int)num;
    int decPart = (int)((num - intPart) * (int)(1e6 + 0.5));
    int i, j;
    int scale = 1;
    for (i = 0; i < decLen; i++) scale *= 10;
    decPart = (int)((num - intPart) * scale + 0.5f);
    if (decPart >= scale) { intPart++; decPart = 0; }

    j = 0;
    for (i = 0; i < intLen; i++) buf[j++] = ' ';
    j = intLen;
    buf[j++] = (intPart / 10) ? (intPart / 10 + '0') : '0';
    buf[j++] = intPart % 10 + '0';
    if (decLen > 0) {
        buf[j++] = '.';
        for (i = decLen - 1; i >= 0; i--) {
            int d = decPart;
            int k;
            for (k = 0; k < i; k++) d /= 10;
            buf[j++] = (d % 10) + '0';
        }
    }
    buf[j] = '\0';
    OLED_ShowStr(x, y, buf, size);
}
