#ifndef __OLED_H
#define __OLED_H

#include "stm32f4xx.h"

/* I2C 软件模拟引脚: PB6=SCL, PB7=SDA */
#define OLED_SCL_PORT   GPIOB
#define OLED_SCL_PIN    GPIO_Pin_6
#define OLED_SDA_PORT   GPIOB
#define OLED_SDA_PIN    GPIO_Pin_7
#define OLED_I2C_CLK    RCC_AHB1Periph_GPIOB

#define OLED_ADDR       0x78    /* 0x3C << 1 */

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowStr(uint8_t x, uint8_t y, const char *str, uint8_t size);
void OLED_ShowNum(uint8_t x, uint8_t y, uint32_t num, uint8_t len, uint8_t size);
void OLED_ShowFloat(uint8_t x, uint8_t y, float num, uint8_t intLen, uint8_t decLen, uint8_t size);

#endif
