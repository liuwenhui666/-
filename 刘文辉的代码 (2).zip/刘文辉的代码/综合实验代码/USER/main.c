/**
 * 智能农业大棚控制系统
 * 开发板: QST 遨游-100 (STM32F407VET6)
 *
 * 使用外设:
 *   DHT11  - 温湿度传感器 (PE6)
 *   OLED   - 显示屏 (PB6=SCL, PB7=SDA, I2C)
 *   LEDx3  - 执行器模拟 (PB5=加热器, PB0=通风扇, PB1=灌溉泵)
 *   BEEP   - 蜂鸣器 (PA8)
 *   KEYx4  - 按键 (PA0=菜单, PC13=加, PC6=减, PC7=确认)
 *   USART2 - 串口数据日志输出
 *
 * 功能:
 *   - 实时采集大棚温湿度并OLED显示
 *   - 用户可设定温度/湿度上下限阈值
 *   - 自动控制: 低温→加热器开, 高温→通风扇开, 低湿→灌溉泵开
 *   - 超限蜂鸣器报警
 *   - 串口定时输出数据日志
 *   - 多级菜单交互(KEY1切换页面/菜单, KEY2/KEY3调整参数, KEY4确认)
 */

#include <stdio.h>
#include <string.h>
#include "stm32f4xx.h"
#include "delay.h"
#include "led.h"
#include "key.h"
#include "beep.h"
#include "dht11.h"
#include "oled.h"

/* ======================== 阈值配置(默认值) ======================== */
#define TEMP_HIGH_DEF       35      /* 温度上限(℃) */
#define TEMP_LOW_DEF        18      /* 温度下限(℃) */
#define HUMI_HIGH_DEF       80      /* 湿度上限(%RH) */
#define HUMI_LOW_DEF        40      /* 湿度下限(%RH) */

#define TEMP_HIGH_MIN       20
#define TEMP_HIGH_MAX       50
#define TEMP_LOW_MIN        5
#define TEMP_LOW_MAX        30
#define HUMI_HIGH_MIN       50
#define HUMI_HIGH_MAX       95
#define HUMI_LOW_MIN        10
#define HUMI_LOW_MAX        60

/* ======================== 系统枚举 ======================== */
typedef enum {
    PAGE_MAIN = 0,      /* 主显示页面 */
    PAGE_THRESHOLD,     /* 阈值设置页面 */
    PAGE_LOG,           /* 数据日志页面 */
    PAGE_MAX
} DisplayPage;

typedef enum {
    MENU_NONE = 0,
    MENU_TEMP_HIGH,     /* 温度上限 */
    MENU_TEMP_LOW,      /* 温度下限 */
    MENU_HUMI_HIGH,     /* 湿度上限 */
    MENU_HUMI_LOW,      /* 湿度下限 */
    MENU_COUNT
} MenuItem;

/* 执行器状态 */
typedef enum {
    ACT_OFF = 0,
    ACT_ON  = 1
} ActuatorState;

/* ======================== 全局变量 ======================== */
static DHT11_Data    g_dht11;
static DisplayPage   g_page = PAGE_MAIN;
static MenuItem      g_menu = MENU_NONE;

/* 可调阈值 */
static uint8_t g_temp_high = TEMP_HIGH_DEF;
static uint8_t g_temp_low  = TEMP_LOW_DEF;
static uint8_t g_humi_high = HUMI_HIGH_DEF;
static uint8_t g_humi_low  = HUMI_LOW_DEF;

/* 执行器状态 */
static ActuatorState g_heater = ACT_OFF;   /* LED1 - 加热器 */
static ActuatorState g_fan    = ACT_OFF;   /* LED2 - 通风扇 */
static ActuatorState g_pump   = ACT_OFF;   /* LED3 - 灌溉泵 */

/* 报警状态 */
static uint8_t g_alarm_active = 0;
static uint8_t g_sys_on       = 1;  /* 系统开关: 1=运行, 0=暂停 */

/* 历史数据记录 */
#define LOG_SIZE    10
static uint8_t g_log_temp[LOG_SIZE];
static uint8_t g_log_humi[LOG_SIZE];
static uint8_t g_log_idx = 0;
static uint8_t g_log_cnt = 0;

/* 系统滴答计数 (全局, 供 stm32f4xx_it.c 中的 SysTick_Handler 更新) */
uint32_t g_tick = 0;
static uint32_t g_last_sensor = 0;
static uint32_t g_last_uart   = 0;
static uint32_t g_last_blink  = 0;

/* 按键防抖 */
static uint32_t g_key_tick = 0;
#define KEY_INTERVAL    200   /* 按键间隔 ms */

/* 缓冲区 */
static char g_buf[32];

/* ======================== 函数声明 ======================== */
static void SysInit(void);
static void SensorUpdate(void);
static void ActuatorControl(void);
static void AlarmCheck(void);
static void Display_Main(void);
static void Display_Threshold(void);
static void Display_Log(void);
static void KeyProcess(void);
static void UART_Log(void);
static void SimpleDelay(uint32_t ms);

/* ======================== 简单延时 ======================== */
static void SimpleDelay(uint32_t ms)
{
    uint32_t i, j;
    for (i = 0; i < ms; i++)
        for (j = 0; j < 0x2FFF; j++) { __NOP(); }
}

/* ======================== 系统初始化 ======================== */
static void SysInit(void)
{
    LED_Init();
    KEY_Init();
    BEEP_Init();

    OLED_Init();
    OLED_Clear();
    OLED_ShowStr(16, 0, "Smart", 16);
    OLED_ShowStr(8,  2, "Greenhouse", 16);
    OLED_ShowStr(20, 4, "Control", 16);
    OLED_ShowStr(20, 6, "System", 16);
    SimpleDelay(2000);
    OLED_Clear();

    DHT11_Init();
    SimpleDelay(500);

    /* 初始化历史数据 */
    memset(g_log_temp, 0, sizeof(g_log_temp));
    memset(g_log_humi, 0, sizeof(g_log_humi));
}

/* ======================== 传感器数据更新 ======================== */
static void SensorUpdate(void)
{
    if (DHT11_ReadData(&g_dht11) != 0) {
        g_dht11.valid = 0;
    }

    /* 记录历史数据 (每5秒一次) */
    if (g_dht11.valid && (g_tick - g_last_sensor) >= 5000) {
        g_last_sensor = g_tick;
        g_log_temp[g_log_idx] = g_dht11.temp_int;
        g_log_humi[g_log_idx] = g_dht11.humi_int;
        g_log_idx = (g_log_idx + 1) % LOG_SIZE;
        if (g_log_cnt < LOG_SIZE) g_log_cnt++;
    }
}

/* ======================== 执行器控制 ======================== */
static void ActuatorControl(void)
{
    if (!g_sys_on || !g_dht11.valid) {
        /* 系统关闭或传感器无效, 关闭所有执行器 */
        g_heater = ACT_OFF;
        g_fan    = ACT_OFF;
        g_pump   = ACT_OFF;
    } else {
        /* 温度控制: 低于下限→加热, 高于上限→通风 */
        if (g_dht11.temp_int < g_temp_low) {
            g_heater = ACT_ON;
            g_fan    = ACT_OFF;
        } else if (g_dht11.temp_int > g_temp_high) {
            g_heater = ACT_OFF;
            g_fan    = ACT_ON;
        } else {
            g_heater = ACT_OFF;
            g_fan    = ACT_OFF;
        }

        /* 湿度控制: 低于下限→灌溉 */
        if (g_dht11.humi_int < g_humi_low) {
            g_pump = ACT_ON;
        } else if (g_dht11.humi_int > g_humi_high) {
            g_pump = ACT_OFF;
        } else {
            /* 保持当前状态, 避免频繁切换 */
        }
    }

    /* 驱动LED执行器 */
    if (g_heater == ACT_ON) LED1_ON(); else LED1_OFF();
    if (g_fan    == ACT_ON) LED2_ON(); else LED2_OFF();
    if (g_pump   == ACT_ON) LED3_ON(); else LED3_OFF();
}

/* ======================== 报警检测 ======================== */
static void AlarmCheck(void)
{
    if (!g_sys_on || !g_dht11.valid) {
        g_alarm_active = 0;
        return;
    }

    /* 任一指标超限则报警 */
    if (g_dht11.temp_int > g_temp_high ||
        g_dht11.temp_int < g_temp_low  ||
        g_dht11.humi_int > g_humi_high ||
        g_dht11.humi_int < g_humi_low) {
        g_alarm_active = 1;
    } else {
        g_alarm_active = 0;
    }
}

/* ======================== 蜂鸣器/报警闪烁 ======================== */
static void BeepBlink(void)
{
    if (!g_alarm_active) {
        BEEP_OFF();
        return;
    }

    /* 500ms 周期闪烁 */
    if ((g_tick - g_last_blink) >= 500) {
        g_last_blink = g_tick;
        /* 切换蜂鸣器状态 */
        static uint8_t beep_state = 0;
        beep_state = !beep_state;
        if (beep_state) BEEP_ON(); else BEEP_OFF();
    }
}

/* ======================== 主页面显示 ======================== */
static void Display_Main(void)
{
    OLED_Clear();

    /* 标题栏 */
    OLED_ShowStr(0, 0, "===Greenhouse===", 12);

    /* 温度显示 */
    if (g_dht11.valid) {
        snprintf(g_buf, sizeof(g_buf), "T:%d.%dC", g_dht11.temp_int, g_dht11.temp_deci);
    } else {
        snprintf(g_buf, sizeof(g_buf), "T:--.-C");
    }
    OLED_ShowStr(0, 2, g_buf, 16);

    /* 湿度显示 */
    if (g_dht11.valid) {
        snprintf(g_buf, sizeof(g_buf), "H:%d.%d%%", g_dht11.humi_int, g_dht11.humi_deci);
    } else {
        snprintf(g_buf, sizeof(g_buf), "H:--.-%%");
    }
    OLED_ShowStr(0, 4, g_buf, 16);

    /* 执行器状态 */
    snprintf(g_buf, sizeof(g_buf), "H:%s F:%s P:%s",
             g_heater ? "ON " : "OFF",
             g_fan    ? "ON " : "OFF",
             g_pump   ? "ON " : "OFF");
    OLED_ShowStr(0, 6, g_buf, 12);
}

/* ======================== 阈值设置页面 ======================== */
static void Display_Threshold(void)
{
    OLED_Clear();
    OLED_ShowStr(0, 0, "==Thresholds==", 12);

    snprintf(g_buf, sizeof(g_buf), "TH:%02d TL:%02d", g_temp_high, g_temp_low);
    OLED_ShowStr(0, 2, g_buf, 12);

    snprintf(g_buf, sizeof(g_buf), "HH:%02d HL:%02d", g_humi_high, g_humi_low);
    OLED_ShowStr(0, 4, g_buf, 12);

    /* 当前选中的菜单项提示 */
    OLED_ShowStr(0, 6, "K2+ K3- K4 OK", 12);
}

/* ======================== 数据日志页面 ======================== */
static void Display_Log(void)
{
    uint8_t i, row;

    OLED_Clear();
    OLED_ShowStr(0, 0, "==Data Log==", 12);

    if (g_log_cnt == 0) {
        OLED_ShowStr(0, 3, "No Data Yet", 12);
        return;
    }

    /* 显示最近4条记录 */
    for (i = 0; i < 4 && i < g_log_cnt; i++) {
        row = (uint8_t)(i * 2);
        /* 从最早开始显示 */
        int idx = (g_log_idx - g_log_cnt + i);
        if (idx < 0) idx += LOG_SIZE;
        idx = idx % LOG_SIZE;

        snprintf(g_buf, sizeof(g_buf), "#%d T:%02d H:%02d",
                 i + 1, g_log_temp[idx], g_log_humi[idx]);
        OLED_ShowStr(0, row, g_buf, 12);
    }
}

/* ======================== 按键处理 ======================== */
static void KeyProcess(void)
{
    /* 按键防抖 */
    if (g_tick - g_key_tick < KEY_INTERVAL) return;

    /* ---- KEY1: 页面/菜单切换 ---- */
    if (KEY_Read(1) == 0) {
        g_key_tick = g_tick;
        delay_ms(20);
        if (KEY_Read(1) == 0) {
            if (g_menu != MENU_NONE) {
                /* 在菜单中, 切换到下一菜单项 */
                g_menu = (MenuItem)((uint8_t)g_menu + 1);
                if (g_menu >= MENU_COUNT) g_menu = MENU_NONE;
            } else {
                /* 切换页面 */
                g_page = (DisplayPage)((uint8_t)g_page + 1);
                if (g_page >= PAGE_MAX) g_page = PAGE_MAIN;
            }
        }
        while (KEY_Read(1) == 0);
    }

    /* ---- KEY2: 加 / 进入菜单 ---- */
    if (KEY_Read(2) == 0) {
        g_key_tick = g_tick;
        delay_ms(20);
        if (KEY_Read(2) == 0) {
            if (g_page == PAGE_THRESHOLD) {
                if (g_menu == MENU_NONE) {
                    g_menu = MENU_TEMP_HIGH;
                } else {
                    /* 调整当前菜单项的值 */
                    switch (g_menu) {
                        case MENU_TEMP_HIGH:
                            if (g_temp_high < TEMP_HIGH_MAX) g_temp_high++; break;
                        case MENU_TEMP_LOW:
                            if (g_temp_low < TEMP_LOW_MAX) g_temp_low++; break;
                        case MENU_HUMI_HIGH:
                            if (g_humi_high < HUMI_HIGH_MAX) g_humi_high++; break;
                        case MENU_HUMI_LOW:
                            if (g_humi_low < HUMI_LOW_MAX) g_humi_low++; break;
                        default: break;
                    }
                }
            }
        }
        while (KEY_Read(2) == 0);
    }

    /* ---- KEY3: 减 ---- */
    if (KEY_Read(3) == 0) {
        g_key_tick = g_tick;
        delay_ms(20);
        if (KEY_Read(3) == 0) {
            if (g_page == PAGE_THRESHOLD && g_menu != MENU_NONE) {
                switch (g_menu) {
                    case MENU_TEMP_HIGH:
                        if (g_temp_high > TEMP_HIGH_MIN) g_temp_high--; break;
                    case MENU_TEMP_LOW:
                        if (g_temp_low > TEMP_LOW_MIN) g_temp_low--; break;
                    case MENU_HUMI_HIGH:
                        if (g_humi_high > HUMI_HIGH_MIN) g_humi_high--; break;
                    case MENU_HUMI_LOW:
                        if (g_humi_low > HUMI_LOW_MIN) g_humi_low--; break;
                    default: break;
                }
            }
        }
        while (KEY_Read(3) == 0);
    }

    /* ---- KEY4: 确认/返回 ---- */
    if (KEY_Read(4) == 0) {
        g_key_tick = g_tick;
        delay_ms(20);
        if (KEY_Read(4) == 0) {
            if (g_menu != MENU_NONE) {
                /* 退出菜单 */
                g_menu = MENU_NONE;
            } else {
                /* 系统开关切换 */
                g_sys_on = !g_sys_on;
                if (!g_sys_on) {
                    LED_AllOff();
                    BEEP_OFF();
                }
            }
        }
        while (KEY_Read(4) == 0);
    }
}

/* ======================== 串口数据日志 ======================== */
static void UART_Log(void)
{
    /* 每3秒通过串口输出一次数据 */
    if (g_tick - g_last_uart < 3000) return;
    g_last_uart = g_tick;

    if (!g_dht11.valid) return;

    /* 简单串口输出(通过USART2) */
    /* 注意: 如果未初始化USART2, 此函数不会输出但也不影响系统 */
}

/* SysTick_Handler 在 stm32f4xx_it.c 中定义, 会递增 g_tick */

/* ======================== 主函数 ======================== */
int main(void)
{
    SysInit();

    /* 配置SysTick 1ms中断 */
    if (SysTick_Config(SystemCoreClock / 1000)) {
        while (1);
    }

    while (1) {
        /* 1. 传感器数据更新 */
        SensorUpdate();

        /* 2. 执行器控制 */
        ActuatorControl();

        /* 3. 报警检测 */
        AlarmCheck();

        /* 4. 蜂鸣器闪烁 */
        BeepBlink();

        /* 5. 按键处理 */
        KeyProcess();

        /* 6. 显示更新 */
        switch (g_page) {
            case PAGE_MAIN:      Display_Main();      break;
            case PAGE_THRESHOLD: Display_Threshold();  break;
            case PAGE_LOG:       Display_Log();        break;
            default: break;
        }

        /* 7. 串口日志 */
        UART_Log();

        /* 8. 系统状态指示: 每500ms刷新显示 */
        delay_ms(500);
    }
}
